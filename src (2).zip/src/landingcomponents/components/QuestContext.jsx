@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&family=Space+Mono:wght@700&display=swap');

/* =====================================================================
   CareDesk360 Growth Quest — white + blue theme
   Every colour lives here. Change these tokens to re-skin the page.
   (Canvas/SVG colours that can't read CSS vars are mirrored in theme.js)
   ===================================================================== */
:root{
  --ccgs-bg:#FFFFFF;
  --ccgs-ink:#F2F6FC;            /* footer ground */
  --ccgs-surface:#F5F8FE;
  --ccgs-surface-2:#FFFFFF;
  --ccgs-surface-3:#E8F0FC;
  --ccgs-inset:#F1F6FE;          /* inner blocks: options, inputs, chips */
  --ccgs-track:rgba(29,107,243,.10);  /* empty progress tracks */
  --ccgs-line:rgba(16,56,120,.11);
  --ccgs-line-strong:rgba(16,56,120,.22);

  --ccgs-primary:#1D6BF3;        /* main blue */
  --ccgs-primary-deep:#0F4FC4;
  --ccgs-sky:#38A0F7;            /* light blue */
  --ccgs-accent:#0A2F72;         /* navy — GP, rewards, highlights */
  --ccgs-danger:#E5484D;         /* validation only */
  --ccgs-on-primary:#FFFFFF;

  --ccgs-primary-rgb:29,107,243;
  --ccgs-sky-rgb:56,160,247;
  --ccgs-accent-rgb:10,47,114;
  --ccgs-shadow-rgb:16,40,90;

  --ccgs-text:#0B1E3B;
  --ccgs-muted:#4B5D78;
  --ccgs-muted-2:#8190A7;

  --ccgs-r:18px;
  --ccgs-maxw:1180px;
  --ccgs-font-d:"Space Grotesk",system-ui,sans-serif;
  --ccgs-font-b:"Inter",system-ui,sans-serif;
  --ccgs-font-m:"Space Mono",ui-monospace,monospace;
}

:where(.ccgs-root),:where(.ccgs-root) *,:where(.ccgs-root) *::before,:where(.ccgs-root) *::after{box-sizing:border-box;margin:0;padding:0}
:where(.ccgs-root){-webkit-text-size-adjust:100%}
.ccgs-root{
  position:relative;
  background:var(--ccgs-bg);
  color:var(--ccgs-text);
  font-family:var(--ccgs-font-b);
  line-height:1.55;
  overflow-x:clip;
  -webkit-font-smoothing:antialiased;
}
.ccgs-root::before{
  content:"";position:fixed;inset:0;z-index:0;pointer-events:none;
  background:
    radial-gradient(900px 500px at 80% -10%, rgba(var(--ccgs-primary-rgb),.10), transparent 60%),
    radial-gradient(800px 600px at 5% 15%, rgba(var(--ccgs-sky-rgb),.08), transparent 55%),
    radial-gradient(700px 700px at 60% 120%, rgba(var(--ccgs-accent-rgb),.05), transparent 55%);
}
:where(.ccgs-root) img{max-width:100%;display:block}
:where(.ccgs-root) a{color:inherit;text-decoration:none}
:where(.ccgs-root) button{font-family:inherit;cursor:pointer;border:none;background:none;color:inherit}
:where(.ccgs-root) :focus-visible{outline:2.5px solid var(--ccgs-primary);outline-offset:3px;border-radius:6px}

.ccgs-wrap{max-width:var(--ccgs-maxw);margin:0 auto;padding:0 24px;position:relative;z-index:1}
.ccgs-section{padding:110px 0;position:relative;z-index:1}
.ccgs-eyebrow{
  font-family:var(--ccgs-font-m);font-size:11px;letter-spacing:.22em;text-transform:uppercase;
  color:var(--ccgs-primary);display:inline-flex;align-items:center;gap:9px;margin-bottom:18px;
}
.ccgs-eyebrow::before{content:"";width:22px;height:1px;background:var(--ccgs-primary);opacity:.7}
.ccgs-root h1,.ccgs-root h2,.ccgs-root h3{font-family:var(--ccgs-font-d);font-weight:600;line-height:1.08;letter-spacing:-.02em}
h2.ccgs-big{font-size:clamp(30px,4.4vw,52px);max-width:820px}
.ccgs-lede{color:var(--ccgs-muted);font-size:clamp(15px,1.6vw,18px);max-width:620px;margin-top:20px}
.ccgs-mono{font-family:var(--ccgs-font-m)}

/* ---------- BUTTONS ---------- */
.ccgs-btn{
  display:inline-flex;align-items:center;gap:10px;font-weight:600;font-size:15px;
  padding:14px 24px;border-radius:999px;transition:.25s cubic-bezier(.2,.7,.3,1);
  position:relative;white-space:nowrap;
}
.ccgs-btn-primary{background:var(--ccgs-primary);color:var(--ccgs-on-primary);box-shadow:0 10px 30px -10px rgba(var(--ccgs-primary-rgb),.7)}
.ccgs-btn-primary:hover{transform:translateY(-2px);box-shadow:0 16px 40px -12px rgba(var(--ccgs-primary-rgb),.9)}
.ccgs-btn-ghost{border:1px solid var(--ccgs-line-strong);color:var(--ccgs-text);background:var(--ccgs-track)}
.ccgs-btn-ghost:hover{border-color:var(--ccgs-primary);color:var(--ccgs-primary);transform:translateY(-2px)}

/* ---------- GROWTH HUD ---------- */
.ccgs-hud{
  position:fixed;z-index:80;top:78px;right:16px;
  background:rgba(255,255,255,.92);backdrop-filter:blur(14px);
  border:1px solid var(--ccgs-line-strong);border-radius:16px;
  padding:12px 14px;display:flex;flex-direction:column;gap:9px;
  width:236px;box-shadow:0 24px 60px -24px rgba(var(--ccgs-shadow-rgb),.22);
  transition:transform .4s cubic-bezier(.2,.8,.2,1),opacity .3s;
}
.ccgs-hud.ccgs-tucked{transform:translateX(268px)}
.ccgs-hud-top{display:flex;align-items:center;justify-content:space-between;gap:8px}
.ccgs-hud-lvl{display:flex;align-items:center;gap:9px;min-width:0}
.ccgs-hud-badge{
  width:34px;height:34px;border-radius:10px;flex:none;
  background:linear-gradient(145deg,var(--ccgs-primary),var(--ccgs-primary-deep));
  display:grid;place-items:center;color:var(--ccgs-on-primary);font-family:var(--ccgs-font-d);font-weight:700;font-size:15px;
  box-shadow:0 6px 18px -6px rgba(var(--ccgs-primary-rgb),.8);
}
.ccgs-hud-lvl-txt{min-width:0}
.ccgs-hud-lvl-txt .ccgs-k{font-family:var(--ccgs-font-m);font-size:9px;letter-spacing:.16em;color:var(--ccgs-muted-2);text-transform:uppercase}
.ccgs-hud-lvl-txt .ccgs-v{font-family:var(--ccgs-font-d);font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ccgs-hud-gp{text-align:right;flex:none}
.ccgs-hud-gp .ccgs-n{font-family:var(--ccgs-font-m);font-size:18px;color:var(--ccgs-accent);line-height:1}
.ccgs-hud-gp .ccgs-l{font-family:var(--ccgs-font-m);font-size:8px;letter-spacing:.14em;color:var(--ccgs-muted-2);text-transform:uppercase}
.ccgs-hud-bar{height:7px;border-radius:99px;background:var(--ccgs-track);overflow:hidden;position:relative}
.ccgs-hud-bar > i{position:absolute;inset:0;width:0%;background:linear-gradient(90deg,var(--ccgs-primary),var(--ccgs-sky));transition:width .8s cubic-bezier(.2,.8,.2,1)}
.ccgs-hud-foot{display:flex;align-items:center;justify-content:space-between;gap:6px}
.ccgs-hud-badges{display:flex;gap:4px;flex-wrap:wrap}
.ccgs-hud-chip{
  width:20px;height:20px;border-radius:6px;display:grid;place-items:center;font-size:11px;
  background:var(--ccgs-track);border:1px solid var(--ccgs-line);color:var(--ccgs-muted-2);
  transition:.3s;
}
.ccgs-hud-chip.ccgs-on{background:rgba(var(--ccgs-primary-rgb),.16);border-color:var(--ccgs-primary);color:var(--ccgs-primary);transform:scale(1.05)}
.ccgs-hud-toggle{font-family:var(--ccgs-font-m);font-size:9px;letter-spacing:.1em;color:var(--ccgs-muted-2);text-transform:uppercase;padding:3px 6px;border:1px solid var(--ccgs-line);border-radius:6px}
.ccgs-hud-toggle:hover{color:var(--ccgs-primary);border-color:var(--ccgs-primary)}
.ccgs-hud-tab{
  position:fixed;top:78px;right:16px;z-index:79;display:none;
  background:rgba(255,255,255,.92);border:1px solid var(--ccgs-line-strong);border-radius:12px;
  padding:8px 12px;font-family:var(--ccgs-font-m);font-size:11px;color:var(--ccgs-accent);gap:8px;align-items:center;
}
.ccgs-hud-tab.ccgs-show{display:flex}

/* ---------- TOAST ---------- */
.ccgs-toasts{position:fixed;left:50%;bottom:26px;transform:translateX(-50%);z-index:90;display:flex;flex-direction:column;gap:10px;align-items:center;pointer-events:none;width:min(92vw,420px)}
.ccgs-toast{
  background:#FFFFFF;border:1px solid var(--ccgs-line-strong);border-left:3px solid var(--ccgs-primary);
  border-radius:12px;padding:12px 16px;display:flex;align-items:center;gap:12px;
  box-shadow:0 18px 44px -18px rgba(var(--ccgs-shadow-rgb),.22);
  transform:translateY(20px);opacity:0;animation:ccgs-toastIn .4s forwards, ccgs-toastOut .4s forwards 2.8s;
  width:100%;
}
.ccgs-toast .ccgs-ic{width:34px;height:34px;border-radius:9px;display:grid;place-items:center;flex:none;font-size:17px;background:rgba(var(--ccgs-primary-rgb),.15)}
.ccgs-toast.ccgs-gold{border-left-color:var(--ccgs-accent)}
.ccgs-toast.ccgs-gold .ccgs-ic{background:rgba(var(--ccgs-accent-rgb),.15)}
.ccgs-toast .ccgs-t{font-family:var(--ccgs-font-d);font-weight:600;font-size:14px}
.ccgs-toast .ccgs-s{font-size:12px;color:var(--ccgs-muted)}
.ccgs-toast .ccgs-plus{margin-left:auto;font-family:var(--ccgs-font-m);color:var(--ccgs-accent);font-size:13px;flex:none}
@keyframes ccgs-toastIn{to{transform:translateY(0);opacity:1}}
@keyframes ccgs-toastOut{to{transform:translateY(-8px);opacity:0}}

/* ---------- NAVBAR ---------- */
.ccgs-nav{position:sticky;top:0;z-index:70;backdrop-filter:blur(14px);background:var(--ccgs-inset);border-bottom:1px solid var(--ccgs-line);transition:.3s}
.ccgs-nav-in{max-width:var(--ccgs-maxw);margin:0 auto;padding:14px 24px;display:flex;align-items:center;gap:20px}
.ccgs-brand{display:flex;align-items:center;gap:11px;font-family:var(--ccgs-font-d);font-weight:700;font-size:18px;letter-spacing:-.02em}
.ccgs-brand .ccgs-logo{width:34px;height:34px;border-radius:10px;background:linear-gradient(145deg,var(--ccgs-primary),var(--ccgs-primary-deep));display:grid;place-items:center;color:var(--ccgs-on-primary);font-weight:700;box-shadow:0 8px 22px -8px rgba(var(--ccgs-primary-rgb),.9);position:relative;overflow:hidden}
.ccgs-brand .ccgs-logo::after{content:"";position:absolute;inset:0;background:linear-gradient(120deg,transparent 40%,rgba(255,255,255,.5) 50%,transparent 60%);transform:translateX(-120%);animation:ccgs-shine 4.5s ease-in-out infinite}
@keyframes ccgs-shine{0%,60%{transform:translateX(-120%)}80%,100%{transform:translateX(220%)}}
.ccgs-nav-links{display:flex;gap:26px;margin-left:20px}
.ccgs-nav-links a{font-size:14px;color:var(--ccgs-muted);font-weight:500;transition:.2s;position:relative}
.ccgs-nav-links a:hover{color:var(--ccgs-text)}
.ccgs-nav-cta{margin-left:auto;display:flex;align-items:center;gap:14px}
.ccgs-nav-mini{display:none;font-family:var(--ccgs-font-m);font-size:12px;color:var(--ccgs-accent)}

/* ---------- HERO ---------- */
.ccgs-hero{padding:70px 0 90px;position:relative}
.ccgs-hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:56px;align-items:center}
.ccgs-hero-tag{
  display:inline-flex;align-items:center;gap:9px;font-size:12.5px;font-weight:500;color:var(--ccgs-primary);
  background:rgba(var(--ccgs-primary-rgb),.08);border:1px solid rgba(var(--ccgs-primary-rgb),.28);padding:7px 14px;border-radius:999px;margin-bottom:26px;
}
.ccgs-hero-tag .ccgs-dot{width:7px;height:7px;border-radius:50%;background:var(--ccgs-primary);box-shadow:0 0 0 0 rgba(var(--ccgs-primary-rgb),.6);animation:ccgs-pulse 2s infinite}
@keyframes ccgs-pulse{0%{box-shadow:0 0 0 0 rgba(var(--ccgs-primary-rgb),.55)}70%{box-shadow:0 0 0 9px rgba(var(--ccgs-primary-rgb),0)}100%{box-shadow:0 0 0 0 rgba(var(--ccgs-primary-rgb),0)}}
.ccgs-hero h1{font-size:clamp(38px,6vw,66px);font-weight:600}
.ccgs-hero h1 .ccgs-accent{background:linear-gradient(100deg,var(--ccgs-primary),var(--ccgs-sky));-webkit-background-clip:text;background-clip:text;color:transparent}
.ccgs-hero p.ccgs-sub{color:var(--ccgs-muted);font-size:clamp(16px,1.8vw,19px);margin-top:22px;max-width:520px}
.ccgs-hero-cta{display:flex;gap:14px;margin-top:34px;flex-wrap:wrap}
.ccgs-hero-stats{display:flex;gap:12px;margin-top:44px;flex-wrap:wrap}
.ccgs-hstat{flex:1;min-width:130px;background:var(--ccgs-surface);border:1px solid var(--ccgs-line);border-radius:14px;padding:16px 18px}
.ccgs-hstat .ccgs-n{font-family:var(--ccgs-font-d);font-weight:700;font-size:26px;background:linear-gradient(120deg,var(--ccgs-primary),var(--ccgs-sky));-webkit-background-clip:text;background-clip:text;color:transparent}
.ccgs-hstat .ccgs-l{font-size:12.5px;color:var(--ccgs-muted);margin-top:3px}

/* hero console */
.ccgs-console{
  background:linear-gradient(180deg,var(--ccgs-surface-2),var(--ccgs-surface));
  border:1px solid var(--ccgs-line-strong);border-radius:24px;padding:22px;position:relative;overflow:hidden;
  box-shadow:0 40px 90px -40px rgba(var(--ccgs-shadow-rgb),.22), inset 0 1px 0 var(--ccgs-track);
}
.ccgs-console::before{content:"";position:absolute;inset:0;background:radial-gradient(400px 200px at 80% 0%,rgba(var(--ccgs-primary-rgb),.12),transparent 60%);pointer-events:none}
.ccgs-console-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.ccgs-console-head .ccgs-lbl{font-family:var(--ccgs-font-m);font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:var(--ccgs-muted-2)}
.ccgs-console-head .ccgs-live{display:flex;align-items:center;gap:6px;font-family:var(--ccgs-font-m);font-size:10px;color:var(--ccgs-primary)}
.ccgs-console-head .ccgs-live i{width:7px;height:7px;border-radius:50%;background:var(--ccgs-primary);animation:ccgs-pulse 2s infinite}
.ccgs-vitals{position:relative;height:150px;border-radius:14px;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);overflow:hidden}
.ccgs-vitals svg{position:absolute;inset:0;width:100%;height:100%}
.ccgs-grid-lines{stroke:rgba(var(--ccgs-shadow-rgb),.08);stroke-width:1}
.ccgs-pulse-path{fill:none;stroke:url(#ccgs-pg);stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 6px rgba(var(--ccgs-primary-rgb),.55))}
.ccgs-pulse-dot{fill:var(--ccgs-primary);filter:drop-shadow(0 0 8px var(--ccgs-primary))}
.ccgs-vitals .ccgs-rise{position:absolute;right:12px;top:12px;font-family:var(--ccgs-font-m);font-size:11px;color:var(--ccgs-primary)}
.ccgs-journey{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:14px}
.ccgs-jstage{
  background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:12px;padding:12px 10px;text-align:center;
  transition:.25s;position:relative;overflow:hidden;
}
.ccgs-jstage:hover{border-color:var(--ccgs-primary);transform:translateY(-3px)}
.ccgs-jstage.ccgs-done{border-color:var(--ccgs-primary);background:rgba(var(--ccgs-primary-rgb),.1)}
.ccgs-jstage .ccgs-ji{font-size:20px;margin-bottom:6px;display:block}
.ccgs-jstage .ccgs-jt{font-family:var(--ccgs-font-d);font-weight:600;font-size:13px}
.ccgs-jstage .ccgs-js{font-size:10px;color:var(--ccgs-muted-2);margin-top:2px}
.ccgs-jstage .ccgs-check{position:absolute;top:6px;right:8px;font-size:11px;color:var(--ccgs-primary);opacity:0;transition:.25s}
.ccgs-jstage.ccgs-done .ccgs-check{opacity:1}
.ccgs-jhint{text-align:center;font-size:11px;color:var(--ccgs-muted-2);margin-top:10px;font-family:var(--ccgs-font-m)}
.ccgs-console-metrics{display:flex;gap:8px;margin-top:12px}
.ccgs-cmetric{flex:1;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:10px;padding:9px 10px}
.ccgs-cmetric .ccgs-l{font-size:9.5px;color:var(--ccgs-muted-2);font-family:var(--ccgs-font-m);text-transform:uppercase;letter-spacing:.1em}
.ccgs-cmetric .ccgs-v{font-family:var(--ccgs-font-d);font-weight:600;font-size:13px;color:var(--ccgs-primary);margin-top:3px}

/* marquee */
.ccgs-marquee{border-top:1px solid var(--ccgs-line);border-bottom:1px solid var(--ccgs-line);padding:16px 0;overflow:hidden;background:var(--ccgs-inset)}
.ccgs-marquee-track{display:flex;gap:34px;white-space:nowrap;animation:ccgs-scroll 22s linear infinite;width:max-content}
.ccgs-marquee:hover .ccgs-marquee-track{animation-play-state:paused}
.ccgs-marquee span{font-family:var(--ccgs-font-d);font-weight:600;font-size:14px;letter-spacing:.04em;color:var(--ccgs-muted);display:inline-flex;align-items:center;gap:34px}
.ccgs-marquee span::after{content:"✦";color:var(--ccgs-primary)}
@keyframes ccgs-scroll{to{transform:translateX(-50%)}}

/* ---------- QUIZ (Growth Score) ---------- */
.ccgs-quiz{background:linear-gradient(180deg,var(--ccgs-surface),var(--ccgs-bg));border-top:1px solid var(--ccgs-line);border-bottom:1px solid var(--ccgs-line)}
.ccgs-quiz-grid{display:grid;grid-template-columns:.9fr 1.1fr;gap:48px;align-items:center}
.ccgs-gauge-wrap{position:relative;display:grid;place-items:center}
.ccgs-gauge{width:min(340px,80vw)}
.ccgs-gauge-num{position:absolute;top:58%;left:50%;transform:translate(-50%,-50%);text-align:center}
.ccgs-gauge-num .ccgs-n{font-family:var(--ccgs-font-d);font-weight:700;font-size:64px;line-height:1;background:linear-gradient(120deg,var(--ccgs-primary),var(--ccgs-sky));-webkit-background-clip:text;background-clip:text;color:transparent}
.ccgs-gauge-num .ccgs-l{font-family:var(--ccgs-font-m);font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:var(--ccgs-muted-2);margin-top:6px}
.ccgs-gauge-tier{margin-top:6px;font-family:var(--ccgs-font-d);font-weight:600;font-size:15px;color:var(--ccgs-primary);min-height:20px}
.ccgs-quiz-card{background:var(--ccgs-surface-2);border:1px solid var(--ccgs-line-strong);border-radius:20px;padding:26px}
.ccgs-quiz-q{font-family:var(--ccgs-font-d);font-weight:600;font-size:19px;margin-bottom:4px}
.ccgs-quiz-step{font-family:var(--ccgs-font-m);font-size:11px;color:var(--ccgs-muted-2);letter-spacing:.12em;text-transform:uppercase;margin-bottom:16px}
.ccgs-quiz-opts{display:flex;flex-direction:column;gap:9px}
.ccgs-qopt{
  text-align:left;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:12px;
  padding:14px 16px;font-size:14.5px;color:var(--ccgs-text);transition:.2s;display:flex;align-items:center;gap:12px;
}
.ccgs-qopt:hover{border-color:var(--ccgs-primary);background:rgba(var(--ccgs-primary-rgb),.08);transform:translateX(3px)}
.ccgs-qopt .ccgs-k{width:24px;height:24px;border-radius:7px;flex:none;display:grid;place-items:center;font-family:var(--ccgs-font-m);font-size:12px;background:var(--ccgs-track);border:1px solid var(--ccgs-line)}
.ccgs-quiz-prog{height:5px;border-radius:99px;background:var(--ccgs-track);margin-top:20px;overflow:hidden}
.ccgs-quiz-prog i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--ccgs-primary),var(--ccgs-sky));transition:width .4s}
.ccgs-quiz-result{display:none}
.ccgs-quiz-result.ccgs-show{display:block;animation:ccgs-fadeUp .5s}
.ccgs-quiz-result h3{font-size:22px;margin-bottom:10px}
.ccgs-quiz-result p{color:var(--ccgs-muted);font-size:14.5px}
.ccgs-quiz-rec{margin-top:18px;padding:16px;border-radius:14px;background:rgba(var(--ccgs-primary-rgb),.08);border:1px solid rgba(var(--ccgs-primary-rgb),.28)}
.ccgs-quiz-rec .ccgs-l{font-family:var(--ccgs-font-m);font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--ccgs-primary)}
.ccgs-quiz-rec .ccgs-v{font-family:var(--ccgs-font-d);font-weight:600;font-size:18px;margin-top:4px}
.ccgs-quiz-result .ccgs-btn{margin-top:18px}
@keyframes ccgs-fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}

/* ---------- CARD GRIDS ---------- */
.ccgs-grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:44px}
.ccgs-grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:44px}
.ccgs-grid-2{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;margin-top:44px}
.ccgs-ocard{background:var(--ccgs-surface);border:1px solid var(--ccgs-line);border-radius:var(--ccgs-r);padding:24px;transition:.3s;position:relative;overflow:hidden}
.ccgs-ocard:hover{border-color:var(--ccgs-line-strong);transform:translateY(-4px);background:var(--ccgs-surface-2)}
.ccgs-ocard .ccgs-num{font-family:var(--ccgs-font-m);font-size:12px;color:var(--ccgs-primary);letter-spacing:.1em}
.ccgs-ocard h3{font-size:19px;margin:16px 0 10px}
.ccgs-ocard p{font-size:14px;color:var(--ccgs-muted)}
.ccgs-ocard::after{content:"";position:absolute;left:0;bottom:0;height:2px;width:0;background:linear-gradient(90deg,var(--ccgs-primary),var(--ccgs-sky));transition:width .4s}
.ccgs-ocard:hover::after{width:100%}

/* collectible flip cards */
.ccgs-fcard{perspective:1000px;height:210px;cursor:pointer}
.ccgs-fcard-in{position:relative;width:100%;height:100%;transition:transform .6s cubic-bezier(.2,.8,.2,1);transform-style:preserve-3d}
.ccgs-fcard.ccgs-flipped .ccgs-fcard-in{transform:rotateY(180deg)}
.ccgs-fface{position:absolute;inset:0;backface-visibility:hidden;border-radius:var(--ccgs-r);border:1px solid var(--ccgs-line);padding:22px;display:flex;flex-direction:column;overflow:hidden}
.ccgs-fface.ccgs-front{background:var(--ccgs-surface)}
.ccgs-fface.ccgs-back{background:linear-gradient(160deg,var(--ccgs-surface-2),var(--ccgs-surface));transform:rotateY(180deg);border-color:rgba(var(--ccgs-primary-rgb),.3)}
.ccgs-fcard.ccgs-flipped .ccgs-fface.ccgs-front{opacity:0}
.ccgs-fnum{font-family:var(--ccgs-font-m);font-size:12px;color:var(--ccgs-primary)}
.ccgs-ficon{font-size:26px;margin:auto 0 12px}
.ccgs-fface h3{font-size:18px;margin-bottom:6px}
.ccgs-fface .ccgs-hint{margin-top:auto;font-family:var(--ccgs-font-m);font-size:10.5px;color:var(--ccgs-muted-2);letter-spacing:.08em}
.ccgs-fface.ccgs-back p{font-size:13.5px;color:var(--ccgs-muted);margin-top:6px}
.ccgs-fface.ccgs-back .ccgs-got{margin-top:auto;font-family:var(--ccgs-font-m);font-size:10.5px;color:var(--ccgs-primary);display:flex;align-items:center;gap:6px}
.ccgs-collect-bar{display:flex;align-items:center;gap:14px;margin-top:30px;flex-wrap:wrap}
.ccgs-collect-bar .ccgs-dots{display:flex;gap:6px}
.ccgs-cdot{width:11px;height:11px;border-radius:50%;background:var(--ccgs-track);transition:.3s}
.ccgs-cdot.ccgs-on{background:var(--ccgs-primary);box-shadow:0 0 10px rgba(var(--ccgs-primary-rgb),.7)}
.ccgs-collect-bar .ccgs-txt{font-family:var(--ccgs-font-m);font-size:12px;color:var(--ccgs-muted)}

.ccgs-pill-note{display:inline-flex;align-items:center;gap:10px;margin-top:26px;background:var(--ccgs-surface);border:1px solid var(--ccgs-line);border-radius:12px;padding:12px 18px;font-size:13.5px;color:var(--ccgs-muted)}
.ccgs-pill-note b{color:var(--ccgs-text);font-family:var(--ccgs-font-d)}

/* ---------- WHY STATS ---------- */
.ccgs-why{background:linear-gradient(180deg,var(--ccgs-bg),var(--ccgs-surface))}
.ccgs-why-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:44px}
.ccgs-wstat{background:var(--ccgs-surface-2);border:1px solid var(--ccgs-line);border-radius:var(--ccgs-r);padding:24px}
.ccgs-wstat .ccgs-n{font-family:var(--ccgs-font-d);font-weight:700;font-size:clamp(28px,3.4vw,40px);line-height:1;background:linear-gradient(120deg,var(--ccgs-primary),var(--ccgs-sky));-webkit-background-clip:text;background-clip:text;color:transparent}
.ccgs-wstat h3{font-size:16px;margin:14px 0 8px}
.ccgs-wstat p{font-size:13px;color:var(--ccgs-muted)}

/* ---------- COMPARISON ---------- */
.ccgs-cmp-wrap{margin-top:40px;border:1px solid var(--ccgs-line-strong);border-radius:20px;overflow:hidden;background:var(--ccgs-surface)}
.ccgs-cmp-head{display:grid;grid-template-columns:1.4fr 1fr 1fr 1fr 1fr;gap:1px;background:var(--ccgs-line)}
.ccgs-cmp-head > div{background:var(--ccgs-surface-2);padding:16px 14px;font-size:12.5px}
.ccgs-cmp-head .ccgs-hero-col{background:linear-gradient(160deg,rgba(var(--ccgs-primary-rgb),.16),rgba(var(--ccgs-sky-rgb),.06))}
.ccgs-cmp-head .ccgs-ct{font-family:var(--ccgs-font-d);font-weight:600;font-size:14px}
.ccgs-cmp-head .ccgs-cs{color:var(--ccgs-muted-2);font-size:11px;margin-top:2px}
.ccgs-cmp-row{display:grid;grid-template-columns:1.4fr 1fr 1fr 1fr 1fr;gap:1px;background:var(--ccgs-line)}
.ccgs-cmp-row > div{background:var(--ccgs-surface);padding:15px 14px;font-size:13px;color:var(--ccgs-muted);display:flex;align-items:center}
.ccgs-cmp-row .ccgs-need{color:var(--ccgs-text);font-weight:500;font-family:var(--ccgs-font-d);font-size:13.5px}
.ccgs-cmp-row .ccgs-hero-col{background:rgba(var(--ccgs-primary-rgb),.06);color:var(--ccgs-text)}
.ccgs-cmp-row .ccgs-hero-col .ccgs-yes{color:var(--ccgs-primary);font-weight:700;margin-right:7px}
.ccgs-cmp-reveal{opacity:.25;filter:blur(2px);transition:.6s;pointer-events:none}
.ccgs-cmp-reveal.ccgs-shown{opacity:1;filter:none;pointer-events:auto}
.ccgs-cmp-cta{display:flex;justify-content:center;margin-top:26px}
.ccgs-cmp-btn-reveal{display:flex;justify-content:center;margin-top:22px}
.ccgs-disc{font-size:11.5px;color:var(--ccgs-muted-2);margin-top:18px;max-width:760px;line-height:1.5}

/* ---------- OFFER (spin) ---------- */
.ccgs-offer{background:linear-gradient(160deg,#EAF2FF,var(--ccgs-bg) 60%);border-top:1px solid rgba(var(--ccgs-primary-rgb),.2)}
.ccgs-offer-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:48px;align-items:center}
.ccgs-offer h2{font-size:clamp(30px,4.4vw,50px)}
.ccgs-offer h2 .ccgs-g{background:linear-gradient(100deg,var(--ccgs-accent),var(--ccgs-primary));-webkit-background-clip:text;background-clip:text;color:transparent}
.ccgs-offer-stats{display:flex;gap:12px;margin-top:28px;flex-wrap:wrap}
.ccgs-ostat{background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:14px;padding:16px;flex:1;min-width:120px}
.ccgs-ostat .ccgs-n{font-family:var(--ccgs-font-d);font-weight:700;font-size:24px;color:var(--ccgs-accent)}
.ccgs-ostat .ccgs-l{font-size:12px;color:var(--ccgs-muted);margin-top:3px}
.ccgs-spinner-card{background:var(--ccgs-surface-2);border:1px solid rgba(var(--ccgs-accent-rgb),.3);border-radius:22px;padding:30px;text-align:center;position:relative;overflow:hidden}
.ccgs-spinner-card::before{content:"";position:absolute;inset:0;background:radial-gradient(300px 200px at 50% 0%,rgba(var(--ccgs-accent-rgb),.14),transparent 60%)}
.ccgs-wheel-box{position:relative;width:220px;height:220px;margin:6px auto 18px}
.ccgs-wheel{width:100%;height:100%;border-radius:50%;transition:transform 4s cubic-bezier(.15,.9,.25,1);position:relative;box-shadow:0 0 0 6px var(--ccgs-inset),0 0 40px -6px rgba(var(--ccgs-accent-rgb),.5)}
.ccgs-wheel-ptr{position:absolute;top:-6px;left:50%;transform:translateX(-50%);z-index:3;color:var(--ccgs-accent);font-size:26px;filter:drop-shadow(0 3px 4px rgba(var(--ccgs-shadow-rgb),.22))}
.ccgs-wheel-hub{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:52px;height:52px;border-radius:50%;background:var(--ccgs-surface);border:2px solid var(--ccgs-accent);z-index:2;display:grid;place-items:center;font-family:var(--ccgs-font-m);font-size:10px;color:var(--ccgs-accent);text-align:center;line-height:1.1}
.ccgs-offer-badge{position:absolute;top:16px;right:16px;background:var(--ccgs-accent);color:var(--ccgs-on-primary);font-family:var(--ccgs-font-m);font-size:11px;font-weight:700;padding:5px 11px;border-radius:99px;letter-spacing:.05em}

/* ---------- GLOBAL REACH ---------- */
.ccgs-reach{position:relative;overflow:hidden}
.ccgs-reach-inner{background:linear-gradient(160deg,var(--ccgs-surface-2),var(--ccgs-surface));border:1px solid var(--ccgs-line-strong);border-radius:24px;padding:44px;position:relative;overflow:hidden}
.ccgs-reach-orbit{position:relative;height:180px;margin-top:28px}
.ccgs-orbit-line{position:absolute;top:50%;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--ccgs-sky),transparent)}
.ccgs-node{position:absolute;top:50%;transform:translateY(-50%);text-align:center}
.ccgs-node .ccgs-ball{width:60px;height:60px;border-radius:50%;display:grid;place-items:center;font-family:var(--ccgs-font-d);font-weight:700;font-size:13px;margin:0 auto 8px}
.ccgs-node.ccgs-g{left:6%}
.ccgs-node.ccgs-g .ccgs-ball{background:rgba(var(--ccgs-sky-rgb),.14);border:1px solid var(--ccgs-sky);color:var(--ccgs-sky)}
.ccgs-node.ccgs-i{right:6%}
.ccgs-node.ccgs-i .ccgs-ball{background:rgba(var(--ccgs-primary-rgb),.14);border:1px solid var(--ccgs-primary);color:var(--ccgs-primary)}
.ccgs-node .ccgs-l{font-size:11px;color:var(--ccgs-muted);font-family:var(--ccgs-font-m)}
.ccgs-travel{position:absolute;top:50%;left:6%;width:12px;height:12px;border-radius:50%;background:var(--ccgs-accent);box-shadow:0 0 14px var(--ccgs-accent);transform:translateY(-50%);animation:ccgs-travel 3.5s ease-in-out infinite}
@keyframes ccgs-travel{0%{left:12%}50%{left:80%}100%{left:12%}}

/* ---------- FOUNDER ---------- */
.ccgs-founder-grid{display:grid;grid-template-columns:.7fr 1.3fr;gap:40px;align-items:center}
.ccgs-founder-photo{background:linear-gradient(160deg,var(--ccgs-surface-2),var(--ccgs-surface));border:1px solid var(--ccgs-line-strong);border-radius:22px;padding:30px;text-align:center}
.ccgs-avatar{width:120px;height:120px;border-radius:50%;margin:0 auto 18px;background:linear-gradient(150deg,var(--ccgs-primary),var(--ccgs-sky));display:grid;place-items:center;font-family:var(--ccgs-font-d);font-weight:700;font-size:42px;color:var(--ccgs-on-primary);box-shadow:0 20px 50px -18px rgba(var(--ccgs-primary-rgb),.7)}
.ccgs-founder-photo .ccgs-fname{font-family:var(--ccgs-font-d);font-weight:600;font-size:20px}
.ccgs-founder-photo .ccgs-frole{font-size:13px;color:var(--ccgs-muted);margin-top:4px}
.ccgs-founder-photo .ccgs-fli{margin-top:16px;display:inline-flex;align-items:center;gap:8px;font-size:13px;color:var(--ccgs-sky);border:1px solid var(--ccgs-line);border-radius:99px;padding:9px 16px;transition:.25s}
.ccgs-founder-photo .ccgs-fli:hover{border-color:var(--ccgs-sky);background:rgba(var(--ccgs-sky-rgb),.08)}

/* ---------- FORM ---------- */
.ccgs-form-section{background:linear-gradient(180deg,var(--ccgs-surface),var(--ccgs-bg))}
.ccgs-form-grid{display:grid;grid-template-columns:.85fr 1.15fr;gap:44px;align-items:start}
.ccgs-form-card{background:var(--ccgs-surface-2);border:1px solid var(--ccgs-line-strong);border-radius:22px;padding:30px}
.ccgs-form-card .ccgs-price{font-family:var(--ccgs-font-d);font-weight:700;font-size:26px;color:var(--ccgs-primary)}
.ccgs-form-card .ccgs-price small{font-size:14px;color:var(--ccgs-muted);font-weight:400}
.ccgs-frow{margin-top:16px}
.ccgs-frow label{display:block;font-size:12.5px;color:var(--ccgs-muted);margin-bottom:7px;font-weight:500}
.ccgs-frow label .ccgs-req{color:var(--ccgs-danger)}
.ccgs-frow input,.ccgs-frow select{width:100%;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:11px;padding:13px 15px;color:var(--ccgs-text);font-family:inherit;font-size:14.5px;transition:.2s}
.ccgs-frow input:focus,.ccgs-frow select:focus{outline:none;border-color:var(--ccgs-primary);background:rgba(var(--ccgs-primary-rgb),.05)}
.ccgs-frow input::placeholder{color:var(--ccgs-muted-2)}
.ccgs-fcheck{display:flex;align-items:flex-start;gap:10px;margin-top:18px;font-size:13px;color:var(--ccgs-muted)}
.ccgs-fcheck input{width:18px;height:18px;margin-top:2px;accent-color:var(--ccgs-primary);flex:none}
.ccgs-form-note{font-size:12px;color:var(--ccgs-muted-2);margin-top:14px}
.ccgs-form-done{display:none;text-align:center;padding:20px 0}
.ccgs-form-done.ccgs-show{display:block;animation:ccgs-fadeUp .5s}
.ccgs-form-done .ccgs-big{font-size:52px}
.ccgs-form-done h3{font-size:22px;margin:10px 0 8px}

/* ---------- FAQ ---------- */
.ccgs-faq-item{border:1px solid var(--ccgs-line);border-radius:14px;margin-bottom:12px;overflow:hidden;background:var(--ccgs-surface);transition:.25s}
.ccgs-faq-item.ccgs-open{border-color:var(--ccgs-line-strong)}
.ccgs-faq-q{width:100%;text-align:left;padding:20px 22px;display:flex;align-items:center;justify-content:space-between;gap:16px;font-family:var(--ccgs-font-d);font-weight:600;font-size:16px}
.ccgs-faq-q .ccgs-tog{width:26px;height:26px;border-radius:8px;flex:none;display:grid;place-items:center;background:rgba(var(--ccgs-primary-rgb),.1);color:var(--ccgs-primary);transition:.3s;font-size:16px}
.ccgs-faq-item.ccgs-open .ccgs-tog{transform:rotate(45deg)}
.ccgs-faq-a{max-height:0;overflow:hidden;transition:max-height .35s ease;color:var(--ccgs-muted);font-size:14.5px}
.ccgs-faq-a > div{padding:0 22px 20px}

/* ---------- TRUST ---------- */
.ccgs-trust-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:40px}
.ccgs-tcard{background:var(--ccgs-surface);border:1px solid var(--ccgs-line);border-radius:var(--ccgs-r);padding:22px;text-align:center;transition:.3s}
.ccgs-tcard:hover{border-color:var(--ccgs-primary);transform:translateY(-4px)}
.ccgs-tcard .ccgs-ti{font-size:24px;color:var(--ccgs-primary);margin-bottom:12px}
.ccgs-tcard h3{font-size:16px;margin-bottom:8px}
.ccgs-tcard p{font-size:12.5px;color:var(--ccgs-muted)}

/* ---------- FOOTER ---------- */
.ccgs-footer{border-top:1px solid var(--ccgs-line);padding:56px 0 40px;background:var(--ccgs-ink)}
.ccgs-footer-top{display:flex;justify-content:space-between;gap:30px;flex-wrap:wrap;align-items:flex-start}
.ccgs-footer .ccgs-brand{font-size:20px}
.ccgs-footer .ccgs-tagline{color:var(--ccgs-muted);font-size:13.5px;margin-top:12px;max-width:340px}
.ccgs-footer-links{display:flex;gap:14px;flex-wrap:wrap}
.ccgs-footer-bot{margin-top:40px;padding-top:24px;border-top:1px solid var(--ccgs-line);display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;font-size:12.5px;color:var(--ccgs-muted-2)}
.ccgs-footer-score{font-family:var(--ccgs-font-m);color:var(--ccgs-accent)}

/* ---------- REVEAL ANIM ---------- */
.ccgs-reveal{opacity:0;transform:translateY(26px);transition:opacity .7s cubic-bezier(.2,.8,.2,1),transform .7s cubic-bezier(.2,.8,.2,1)}
.ccgs-reveal.ccgs-in{opacity:1;transform:none}

/* ---------- LEVEL-UP OVERLAY ---------- */
.ccgs-levelup{position:fixed;inset:0;z-index:100;display:none;place-items:center;background:rgba(var(--ccgs-shadow-rgb),.45);backdrop-filter:blur(6px)}
.ccgs-levelup.ccgs-show{display:grid;animation:ccgs-fadeUp .3s}
.ccgs-levelup-card{background:linear-gradient(160deg,var(--ccgs-surface-2),var(--ccgs-surface));border:1px solid var(--ccgs-primary);border-radius:24px;padding:40px 46px;text-align:center;box-shadow:0 40px 100px -30px rgba(var(--ccgs-primary-rgb),.5);max-width:90vw}
.ccgs-levelup-card .ccgs-burst{font-size:54px;margin-bottom:8px}
.ccgs-levelup-card .ccgs-k{font-family:var(--ccgs-font-m);font-size:12px;letter-spacing:.2em;text-transform:uppercase;color:var(--ccgs-accent)}
.ccgs-levelup-card .ccgs-v{font-family:var(--ccgs-font-d);font-weight:700;font-size:34px;margin:8px 0 6px;background:linear-gradient(120deg,var(--ccgs-primary),var(--ccgs-sky));-webkit-background-clip:text;background-clip:text;color:transparent}
.ccgs-levelup-card .ccgs-d{color:var(--ccgs-muted);font-size:14px;max-width:300px;margin:0 auto}
.ccgs-levelup-card button{margin-top:22px}
.ccgs-confetti{position:fixed;inset:0;z-index:101;pointer-events:none;display:none}
.ccgs-confetti.ccgs-show{display:block}

/* ---------- RESPONSIVE ---------- */
@media(max-width:960px){
  .ccgs-hero-grid,.ccgs-quiz-grid,.ccgs-offer-grid,.ccgs-founder-grid,.ccgs-form-grid{grid-template-columns:1fr;gap:36px}
  .ccgs-grid-4,.ccgs-why-grid,.ccgs-trust-grid{grid-template-columns:repeat(2,1fr)}
  .ccgs-nav-links{display:none}
  .ccgs-section{padding:80px 0}
  .ccgs-cmp-head,.ccgs-cmp-row{grid-template-columns:1.4fr 1fr;overflow-x:auto}
  .ccgs-cmp-head > div:nth-child(n+4),.ccgs-cmp-row > div:nth-child(n+4){display:none}
}
@media(max-width:600px){
  .ccgs-grid-4,.ccgs-why-grid,.ccgs-trust-grid,.ccgs-grid-3,.ccgs-grid-2{grid-template-columns:1fr}
  .ccgs-hud{width:calc(100vw - 28px);right:14px}
  .ccgs-hud.ccgs-tucked{transform:translateY(calc(-100% - 90px))}
  .ccgs-nav-mini{display:block}
  .ccgs-journey{grid-template-columns:repeat(2,1fr)}
  .ccgs-section{padding:64px 0}
  .ccgs-wrap{padding:0 18px}
}
@media(prefers-reduced-motion:reduce){
  .ccgs-root *{animation-duration:.001ms !important;animation-iteration-count:1 !important;transition-duration:.15s !important}
  .ccgs-reveal{opacity:1;transform:none}
}

/* ========== SPIN-TO-WIN OFFER / ENGAGING FORMS / SHARE & LEADERBOARD ========== */
.ccgs-root{max-width:100%;overflow-x:clip} /* keep the 1950px marquee from widening the mobile layout viewport */
/* score breakdown + projection */
.ccgs-score-viz{margin:20px 0 22px;padding:18px 16px;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:16px;text-align:left}
.ccgs-sv-h{font-family:var(--ccgs-font-m);font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--ccgs-muted-2);margin-bottom:12px}
.ccgs-sv-h span{color:var(--ccgs-accent);text-transform:none;letter-spacing:0}
.ccgs-sbar{display:grid;grid-template-columns:86px 1fr 34px;gap:10px;align-items:center;margin-bottom:9px}
.ccgs-sbar .ccgs-l{font-size:12px;color:var(--ccgs-muted);font-weight:500}
.ccgs-sbar .ccgs-t{position:relative;height:9px;border-radius:99px;background:var(--ccgs-track)}
.ccgs-sbar .ccgs-t i{position:absolute;inset:0 auto 0 0;width:0;border-radius:99px;transition:width 1s cubic-bezier(.2,.8,.2,1)}
.ccgs-sbar .ccgs-t .ccgs-bm{position:absolute;top:50%;left:85%;transform:translate(-50%,-50%) rotate(45deg);width:7px;height:7px;background:var(--ccgs-accent);border-radius:2px;box-shadow:0 0 8px rgba(var(--ccgs-accent-rgb),.8)}
.ccgs-sbar .ccgs-v{font-family:var(--ccgs-font-m);font-size:11px;color:var(--ccgs-muted);text-align:right}
.ccgs-proj-chart{width:100%;height:132px;display:block;background:var(--ccgs-inset);border-radius:12px}
.ccgs-proj-legend{display:flex;gap:14px;flex-wrap:wrap;margin-top:10px;font-size:11.5px;color:var(--ccgs-muted)}
.ccgs-pl.ccgs-a{color:var(--ccgs-primary)}.ccgs-pl.ccgs-b{color:var(--ccgs-muted-2)}
.ccgs-pl.ccgs-c{margin-left:auto;font-family:var(--ccgs-font-m);color:var(--ccgs-accent);font-weight:700}
.ccgs-res-row{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap}
.ccgs-res-row .ccgs-btn{flex:1;justify-content:center;min-width:130px}
/* outcome card visuals */
.ccgs-oviz{height:56px;margin:12px 0 4px}
.ccgs-oviz svg{width:100%;height:100%;overflow:visible}
/* HUD name */
.ccgs-hud-name{max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
/* floating spin FAB */
.ccgs-spin-fab{position:fixed;left:50%;bottom:18px;transform:translate(-50%,90px);z-index:85;display:flex;align-items:center;gap:9px;background:linear-gradient(135deg,var(--ccgs-accent),var(--ccgs-primary-deep));color:var(--ccgs-on-primary);font-weight:700;font-size:14px;padding:13px 20px;border-radius:99px;box-shadow:0 18px 40px -12px rgba(var(--ccgs-accent-rgb),.75);transition:transform .45s cubic-bezier(.2,.8,.2,1);white-space:nowrap}
.ccgs-spin-fab.ccgs-show{transform:translate(-50%,0)}
.ccgs-spin-fab:hover{transform:translate(-50%,-3px)}
.ccgs-spin-fab .ccgs-w{display:inline-block;animation:ccgs-fabSpin 5s linear infinite}
@keyframes ccgs-fabSpin{to{transform:rotate(360deg)}}
/* form-done actions */
.ccgs-fd-summary{margin:16px auto 0;max-width:420px;text-align:left;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:13px;padding:14px 16px;font-size:13px;color:var(--ccgs-muted);line-height:1.7}
.ccgs-fd-summary b{color:var(--ccgs-text)}
.ccgs-fd-summary .ccgs-cd{color:var(--ccgs-accent);font-family:var(--ccgs-font-m)}
.ccgs-fd-actions{display:flex;gap:10px;margin-top:16px;flex-wrap:wrap;justify-content:center}
.ccgs-fd-actions .ccgs-btn{flex:1;justify-content:center;min-width:170px}
.ccgs-spinner-card::before{pointer-events:none}
.ccgs-spin-gate,.ccgs-spin-ready,.ccgs-spin-won{position:relative;z-index:1}
.ccgs-btn-gold{background:linear-gradient(135deg,var(--ccgs-accent),var(--ccgs-primary-deep));color:var(--ccgs-on-primary);box-shadow:0 10px 26px -10px rgba(var(--ccgs-accent-rgb),.8)}
.ccgs-btn-gold:hover{transform:translateY(-2px);box-shadow:0 16px 34px -10px rgba(var(--ccgs-accent-rgb),.95)}
.ccgs-btn-gold:disabled{opacity:.55;cursor:not-allowed;transform:none;box-shadow:none}
.ccgs-offer-terms{margin-top:22px;font-size:12px;color:var(--ccgs-muted-2);line-height:1.65;max-width:460px}
.ccgs-offer-terms b{color:var(--ccgs-muted)}
.ccgs-spin-sub{font-size:13px;color:var(--ccgs-muted);margin-bottom:2px;line-height:1.5}
.ccgs-wheel-lbls{position:absolute;inset:0;pointer-events:none}
.ccgs-wheel-lbl{position:absolute;top:50%;left:50%;transform-origin:0 0;font-family:var(--ccgs-font-d);font-weight:700;font-size:15px;color:var(--ccgs-on-primary);text-shadow:0 1px 0 rgba(0,0,0,.18)}
.ccgs-wheel-hub{white-space:pre-line;line-height:1.15}
.ccgs-gfield{margin-top:12px;text-align:left}
.ccgs-gfield label{display:block;font-size:12px;color:var(--ccgs-muted);font-weight:500;margin-bottom:6px}
.ccgs-gin{position:relative}
.ccgs-gin input{width:100%;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:11px;padding:12px 38px 12px 14px;color:var(--ccgs-text);font-family:inherit;font-size:14px;transition:.2s}
.ccgs-gin input:focus{outline:none;border-color:var(--ccgs-accent);background:rgba(var(--ccgs-accent-rgb),.05)}
.ccgs-gin input.ccgs-good{border-color:var(--ccgs-primary)}
.ccgs-gin input.ccgs-bad{border-color:var(--ccgs-danger)}
.ccgs-gin .ccgs-ok{position:absolute;right:12px;top:50%;transform:translateY(-50%) scale(.4);color:var(--ccgs-primary);opacity:0;transition:.25s;font-weight:700;pointer-events:none}
.ccgs-gin input.ccgs-good ~ .ccgs-ok{opacity:1;transform:translateY(-50%) scale(1)}
.ccgs-gmsg{font-size:11.5px;color:var(--ccgs-danger);margin-top:4px;min-height:13px;text-align:left}
.ccgs-gconsent{display:flex;gap:9px;align-items:flex-start;margin-top:10px;font-size:12px;color:var(--ccgs-muted);line-height:1.5;text-align:left;cursor:pointer}
.ccgs-gconsent input{width:16px;height:16px;margin-top:1px;accent-color:var(--ccgs-primary);flex:none}
.ccgs-gate-meter{display:flex;align-items:center;gap:10px;margin-top:14px}
.ccgs-gate-meter .ccgs-bar{flex:1;height:6px;border-radius:99px;background:var(--ccgs-track);overflow:hidden}
.ccgs-gate-meter .ccgs-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--ccgs-accent),var(--ccgs-primary));transition:width .35s}
.ccgs-gate-meter span{font-family:var(--ccgs-font-m);font-size:10px;color:var(--ccgs-muted-2);white-space:nowrap}
.ccgs-ghint{font-size:11.5px;color:var(--ccgs-muted-2);margin-top:10px;text-align:center;font-family:var(--ccgs-font-m)}
.ccgs-won-kicker{font-size:13px;color:var(--ccgs-muted);font-weight:600}
.ccgs-won-big{font-family:var(--ccgs-font-d);font-weight:700;font-size:52px;line-height:1;background:linear-gradient(120deg,var(--ccgs-accent),var(--ccgs-primary));-webkit-background-clip:text;background-clip:text;color:transparent;margin:6px 0 2px}
.ccgs-coupon{margin:14px auto 0;max-width:300px;border:2px dashed var(--ccgs-accent);border-radius:12px;background:rgba(var(--ccgs-accent-rgb),.07);padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px}
.ccgs-coupon .ccgs-code{font-family:var(--ccgs-font-m);font-weight:700;font-size:15px;letter-spacing:.03em;color:var(--ccgs-accent)}
.ccgs-coupon button{background:var(--ccgs-primary);color:var(--ccgs-on-primary);border-radius:8px;padding:8px 13px;font-weight:700;font-size:12.5px}
.ccgs-cd-label{margin-top:16px;font-family:var(--ccgs-font-m);font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--ccgs-muted-2)}
.ccgs-cd-boxes{display:flex;gap:8px;justify-content:center;margin-top:8px}
.ccgs-cd-box{background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:10px;padding:9px 4px;min-width:56px}
.ccgs-cd-box .ccgs-n{font-family:var(--ccgs-font-m);font-size:20px;color:var(--ccgs-text);line-height:1}
.ccgs-cd-box .ccgs-u{font-size:9px;color:var(--ccgs-muted-2);font-family:var(--ccgs-font-m);text-transform:uppercase;letter-spacing:.08em;margin-top:3px}
.ccgs-chip-row{display:flex;gap:8px;flex-wrap:wrap}
.ccgs-chip{flex:1;min-width:96px;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:11px;padding:11px 8px;color:var(--ccgs-text);font-weight:600;font-size:13px;display:flex;flex-direction:column;gap:2px;align-items:center;transition:.2s}
.ccgs-chip span{font-size:10.5px;color:var(--ccgs-muted-2);font-family:var(--ccgs-font-m)}
.ccgs-chip:hover{border-color:var(--ccgs-primary);transform:translateY(-2px)}
.ccgs-chip.ccgs-on{border-color:var(--ccgs-primary);background:rgba(var(--ccgs-primary-rgb),.12);box-shadow:0 6px 18px -8px rgba(var(--ccgs-primary-rgb),.6)}
.ccgs-chip.ccgs-on span{color:var(--ccgs-primary)}
.ccgs-frow input.ccgs-good{border-color:var(--ccgs-primary)}
.ccgs-fmeter{margin-top:18px}
.ccgs-fmeter-top{display:flex;justify-content:space-between;font-size:11px;color:var(--ccgs-muted-2);font-family:var(--ccgs-font-m);margin-bottom:6px}
.ccgs-fmeter-bar{height:6px;border-radius:99px;background:var(--ccgs-track);overflow:hidden}
.ccgs-fmeter-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--ccgs-primary),var(--ccgs-sky));transition:width .35s}
.ccgs-form-offer-note{display:block;margin-top:14px;padding:12px 14px;border-radius:11px;background:rgba(var(--ccgs-accent-rgb),.08);border:1px solid rgba(var(--ccgs-accent-rgb),.35);font-size:13px;color:var(--ccgs-text);line-height:1.5}
.ccgs-form-offer-note b{color:var(--ccgs-accent);font-family:var(--ccgs-font-m)}
.ccgs-hud-tools{display:flex;gap:4px}
.ccgs-hud-ic{width:22px;height:22px;border-radius:6px;display:grid;place-items:center;font-size:12px;background:var(--ccgs-track);border:1px solid var(--ccgs-line);transition:.2s}
.ccgs-hud-ic:hover{border-color:var(--ccgs-primary);transform:scale(1.06)}
.ccgs-gmodal{position:fixed;inset:0;z-index:105;display:none;place-items:center;background:rgba(var(--ccgs-shadow-rgb),.45);backdrop-filter:blur(6px);padding:18px}
.ccgs-gmodal.ccgs-show{display:grid;animation:ccgs-fadeUp .3s}
.ccgs-gmodal-card{background:linear-gradient(160deg,var(--ccgs-surface-2),var(--ccgs-surface));border:1px solid var(--ccgs-line-strong);border-radius:22px;padding:26px;max-width:520px;width:100%;max-height:90vh;overflow:auto;position:relative;box-shadow:0 40px 100px -30px rgba(var(--ccgs-shadow-rgb),.22)}
.ccgs-gmodal-x{position:absolute;top:14px;right:14px;width:30px;height:30px;border-radius:9px;background:var(--ccgs-track);border:1px solid var(--ccgs-line);display:grid;place-items:center;color:var(--ccgs-muted);font-size:13px}
.ccgs-gmodal-x:hover{color:var(--ccgs-text);border-color:var(--ccgs-line-strong)}
.ccgs-gmodal-card h3{font-size:20px;margin:6px 0 4px}
.ccgs-share-canvas{width:100%;height:auto;border-radius:14px;border:1px solid var(--ccgs-line);display:block;margin:14px 0}
.ccgs-share-stats{font-family:var(--ccgs-font-m);font-size:12px;color:var(--ccgs-muted);margin-bottom:14px}
.ccgs-share-actions{display:flex;gap:10px;flex-wrap:wrap}
.ccgs-share-actions .ccgs-btn{flex:1;justify-content:center;min-width:120px}
.ccgs-lb-list{list-style:none;margin:14px 0 6px;display:flex;flex-direction:column;gap:8px;max-height:300px;overflow:auto;padding:0}
.ccgs-lb-row{display:flex;align-items:center;gap:10px;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:11px;padding:10px 12px}
.ccgs-lb-row.ccgs-me{border-color:var(--ccgs-primary);background:rgba(var(--ccgs-primary-rgb),.08)}
.ccgs-lb-rank{width:30px;text-align:center;font-family:var(--ccgs-font-m);font-size:13px;color:var(--ccgs-muted);flex:none}
.ccgs-lb-name{flex:1;font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.ccgs-lb-lv{font-size:11px;color:var(--ccgs-muted-2);white-space:nowrap}
.ccgs-lb-gp{font-family:var(--ccgs-font-m);color:var(--ccgs-accent);font-size:13px;white-space:nowrap}
.ccgs-lb-empty{text-align:center;color:var(--ccgs-muted-2);font-size:13px;padding:14px 0}
.ccgs-lb-submit{display:flex;gap:8px;margin-top:12px}
.ccgs-lb-submit input{flex:1;background:var(--ccgs-inset);border:1px solid var(--ccgs-line);border-radius:10px;padding:11px 13px;color:var(--ccgs-text);font-family:inherit;font-size:13.5px;min-width:0}
.ccgs-lb-submit input:focus{outline:none;border-color:var(--ccgs-primary)}
@media(max-width:600px){
  .ccgs-nav-in{padding:12px 14px;gap:10px}
  .ccgs-brand{font-size:16px;gap:9px}
  .ccgs-brand .ccgs-logo{width:30px;height:30px;border-radius:9px;font-size:14px}
  .ccgs-nav-cta{gap:8px}
  .ccgs-nav-cta .ccgs-btn{padding:10px 14px;font-size:13px}
  .ccgs-nav-mini{display:none}
  .ccgs-levelup-card{padding:30px 20px}
  .ccgs-spinner-card{padding:24px 16px}
  .ccgs-coupon{max-width:100%}
  .ccgs-cd-box{min-width:0;flex:1}
  .ccgs-gmodal-card{padding:22px 16px}
  .ccgs-hud-foot{flex-wrap:wrap;row-gap:6px}
  .ccgs-share-actions .ccgs-btn{min-width:0;flex:1 1 44%}
  .ccgs-share-actions .ccgs-btn:first-child{flex-basis:100%}
  .ccgs-offer h2{font-size:30px}
}

/* ---------- React additions (same look) ---------- */
.ccgs-root a.ccgs-btn,.ccgs-root button.ccgs-btn{cursor:pointer}
.ccgs-btn-primary:disabled{opacity:.6;cursor:not-allowed;transform:none}
.ccgs-refresh-note{font-size:12px;color:var(--ccgs-muted-2);margin-top:14px;font-family:var(--ccgs-font-m)}
