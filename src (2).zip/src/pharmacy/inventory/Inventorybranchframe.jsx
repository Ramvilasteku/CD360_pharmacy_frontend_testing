// src/pharmacy/inventory/InventoryBranchFrame.jsx
//
// The branch bar for an Inventory page reached from the sidebar — added 6 Nov 2026.
// Same pattern as sales/SalesBranchFrame.jsx.
//
// WHY THIS EXISTS
//   The four Inventory pages in the sidebar (Inventory, Stock Adjustment, Stock Ledger,
//   Low Stock — components/pharmacy/*) had no branch at all: no picker for the admin, every
//   list showed the whole pharmacy, and Stock Adjustment never sent a branch, so in a
//   multi-branch pharmacy the server refused every adjustment the admin tried
//   ("Choose the branch first."). This frame gives each page the picker and passes the
//   branch down as `branchState` / `branchParams`, without changing the pages' layout.
//
// TWO MODES
//   write   Stock Adjustment. The admin's WORKING branch — the same one New sale, Receive
//           and B2B use, remembered on this device. Must be chosen before adjusting.
//   read    Inventory, Stock Ledger, Low Stock. Opens on "All branches" every time; a branch
//           picked here filters this page only and never changes the working branch.
//
// WHO SEES WHAT
//   single-branch pharmacy   nothing — the bar does not render at all
//   staff                    their own branch as a chip; they cannot change it, and the
//                            server enforces it regardless (utils/pharmacyBranch.js)
//   admin                    the Branch select

import React from "react";
import { Box, Paper, Stack, Typography } from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import StoreOutlinedIcon from "@mui/icons-material/StoreOutlined";
import BranchPicker, { usePharmacyBranch } from "../shared/BranchPicker";

const HINTS = {
  write: {
    admin: "Adjust stock in this branch — only its batches are listed.",
    staff: "You adjust stock in your branch.",
  },
  read: {
    admin: "Showing every branch. Pick one to narrow the list.",
    staff: "Showing your branch only.",
  },
};

export default function InventoryBranchFrame({ mode = "read", children }) {
  const theme = useTheme();
  const br = usePharmacyBranch(
    mode === "write" ? { allowAll: false } : { allowAll: true, defaultAll: true }
  );

  const child = React.isValidElement(children)
    ? React.cloneElement(children, { branchState: br, branchParams: br.params })
    : children;

  // Nothing to choose in a single-branch pharmacy (or before the branch list loads, so the
  // page never jumps when the bar appears for a pharmacy that has no use for it).
  if (br.loading || !br.multi) return child;

  const who = br.isAdmin ? "admin" : "staff";
  let hint = HINTS[mode][who];
  if (mode === "read" && br.isAdmin && br.branch) hint = `Showing ${br.branch} only.`;
  if (mode === "write" && br.needsChoice) hint = "Choose the branch you are adjusting stock in.";

  return (
    <Box sx={{ minWidth: 0 }}>
      <Paper
        elevation={0}
        sx={{
          mb: 1.5,
          px: { xs: 1.5, sm: 2 },
          py: 1,
          borderRadius: "12px",
          border: `1px solid ${
            br.needsChoice ? theme.palette.warning.main : theme.palette.divider
          }`,
          bgcolor: br.needsChoice
            ? alpha(theme.palette.warning.main, theme.palette.mode === "dark" ? 0.12 : 0.06)
            : "background.paper",
        }}
      >
        <Stack
          direction={{ xs: "column", sm: "row" }}
          alignItems={{ xs: "stretch", sm: "center" }}
          justifyContent="space-between"
          spacing={1}
        >
          <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
            <StoreOutlinedIcon
              sx={{ fontSize: 20, color: br.needsChoice ? "warning.main" : "text.secondary" }}
            />
            <Typography variant="body2" color="text.secondary" sx={{ minWidth: 0 }}>
              {hint}
            </Typography>
          </Stack>
          <BranchPicker
            state={br}
            sx={{ minWidth: { xs: 0, sm: 200 }, width: { xs: "100%", sm: "auto" } }}
          />
        </Stack>
      </Paper>
      {child}
    </Box>
  );
}