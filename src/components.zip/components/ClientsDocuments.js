import {
    Typography,
    Button,
    ButtonGroup,
    IconButton,
    Chip,
    Dialog,
    DialogContent,
    Box,
    Card,
    CardContent,
    CardActions,
    Grid,
} from "@mui/material";
import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import DownloadIcon from "@mui/icons-material/Download";
import VisibilityIcon from "@mui/icons-material/Visibility";
import DeleteIcon from "@mui/icons-material/Delete";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import FolderIcon from '@mui/icons-material/Folder';
import { useState } from "react";
import {
    TextField,
    CircularProgress,
} from "@mui/material";

import Skeleton from "@mui/material/Skeleton";

function ClientDocuments({ client, onBack }) {
    const [activeType, setActiveType] = useState("client");
    const [previewFile, setPreviewFile] = useState(null);
    const [approvalDialog, setApprovalDialog] = useState(false);
    const [selectedDoc, setSelectedDoc] = useState(null);
    const [otpDialog, setOtpDialog] = useState(false);
    const [otp, setOtp] = useState("");
    const [loadingDocId, setLoadingDocId] = useState(null);
    const [verifyingOtp, setVerifyingOtp] = useState(false);
    const [docViewerOpen, setDocViewerOpen] = useState(false);
    const [docViewerUrl, setDocViewerUrl] = useState("");
    const [otpSendingSkeleton, setOtpSendingSkeleton] = useState(false);

    const roleColor = {
        client: "success",
        admin: "primary",
        staff: "secondary",
    };

    const filteredDocs = client.documents.filter(
        (doc) => doc.uploaded_by === activeType
    );
    // console.log("Client Documents:", filteredDocs);

    const getPreviewSrc = (url) => {
        if (!url) return null;

        const lower = url.toLowerCase();

        // DOCX → Google Docs Viewer
        if (lower.endsWith(".docx")) {
            return `https://docs.google.com/gview?url=${encodeURIComponent(
                url
            )}&embedded=true`;
        }

        // PDF / images → direct preview
        return url;
    };


    // CHANGED: open the file in an in-page Dialog instead of a new browser tab
    const openDocument = async (documentId) => {
        try {
            const fileRes = await fetch(
                `${process.env.REACT_APP_URL}/api/documents/view-safe/${documentId}`,
                { method: "GET", credentials: "include" }
            );

            if (!fileRes.ok) {
                let message = "Failed to fetch document";
                try {
                    const err = await fileRes.json();
                    message = err.message || message;
                } catch {
                    message = await fileRes.text().catch(() => message);
                }
                throw new Error(message);
            }

            const blob = await fileRes.blob();
            const url = window.URL.createObjectURL(blob);
            setDocViewerUrl(url);
            setDocViewerOpen(true); // was: window.open(url, "_blank")
        } catch (err) {
            alert(err.message);
        }
    };

    // Matches Documents.jsx's sendOtp: if backend says already verified
    // (within the 4-hour window), skip the OTP dialog and open directly.
    const sendOtp = async (documentId) => {
    try {

        setLoadingDocId(documentId);

        // OPEN SKELETON LOADER
        setOtpSendingSkeleton(true);


        const res = await fetch(
            `${process.env.REACT_APP_URL}/api/documents/send-otp/${documentId}`,
            {
                method: "POST",
                credentials: "include"
            }
        );


        const text = await res.text();

        let data;

        try {
            data = JSON.parse(text);
        } catch {
            data = { message: text };
        }


        if (!res.ok) {
            throw new Error(data.message);
        }


        const isAlreadyVerified =
            data.alreadyVerified === true ||
            (
                typeof data.message === "string" &&
                data.message.toLowerCase().includes("already verified")
            );


        // CLOSE SKELETON
        setOtpSendingSkeleton(false);


        if (isAlreadyVerified) {

            await openDocument(documentId);

            return;
        }


        // OPEN OTP POPUP
        setOtp("");
        setOtpDialog(true);


    } catch(err){

        setOtpSendingSkeleton(false);

        alert(err.message);

    } finally {

        setLoadingDocId(null);

    }
};

const handleViewClick = async (doc) => {
    setSelectedDoc(doc);
    setLoadingDocId(doc.id);   // NEW: mark this doc as loading immediately, so the
                                //      otp-status check below also disables just this icon

    try {
        const statusRes = await fetch(
            `${process.env.REACT_APP_URL}/api/documents/otp-status/${doc.id}`,
            { method: "GET", credentials: "include" }
        );
        const statusData = await statusRes.json();

        if (statusRes.ok && statusData.status === "verified") {
            await openDocument(doc.id);
            setLoadingDocId(null);
            return;
        }
    } catch {
        // fall through to normal OTP flow
    }

    sendOtp(doc.id); // sendOtp manages loadingDocId itself from here on
};


    const verifyOtp = async () => {
        const documentId = selectedDoc?.id;

        if (!documentId) {
            alert("Document not selected");
            return;
        }

        try {
            setVerifyingOtp(true);

            const res = await fetch(
                `${process.env.REACT_APP_URL}/api/documents/verify-otp`,
                {
                    method: "POST",
                    credentials: "include",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ documentId: selectedDoc.id, otp }),
                }
            );

            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.message);
            }

            setOtpDialog(false);
            await openDocument(selectedDoc.id);
        } catch (err) {
            alert(err.message);
        } finally {
            setVerifyingOtp(false);
        }
    };

    // Matches Documents.jsx's checkOtpStatusAndProceed: check otp-status first,
    // and if already verified within the window, open directly without
    // touching send-otp or the OTP dialog at all.
   


    // Cleanup helper for closing the viewer and freeing the blob URL
    const closeDocViewer = () => {
        if (docViewerUrl) {
            window.URL.revokeObjectURL(docViewerUrl);
        }
        setDocViewerUrl("");
        setDocViewerOpen(false);
    };



    return (
        <>
            <Button onClick={onBack} sx={{ mb: 2, mt: 10, color: "#3f6f7a", textTransform: "none" }}>
                ← Back to Clients
            </Button>

            <Typography variant="h6" sx={{ mb: 2 }}>
                {client.client_name}&apos;s Documents
            </Typography>

            {/* ROLE FILTER BUTTONS */}
            <ButtonGroup sx={{ mb: 3 }}>
                {["client", "admin", "staff"].map((type) => {
                    const isActive = activeType === type;

                    return (
                        <Button
                            key={type}
                            variant={isActive ? "contained" : "outlined"}
                            onClick={() => setActiveType(type)}
                            sx={{
                                ...(isActive
                                    ? {
                                        backgroundColor: "#3f6f7a",
                                        color: "#ffffff",
                                        "&:hover": {
                                            backgroundColor: "#355f69",
                                        },
                                        textTransform: "none",
                                    }
                                    : {
                                        borderColor: "#3f6f7a",
                                        color: "#3f6f7a",
                                        "&:hover": {
                                            borderColor: "#355f69",
                                            backgroundColor: "rgba(63, 111, 122, 0.08)",
                                        },
                                        textTransform: "none",
                                    }),
                            }}
                        >
                            {type}
                        </Button>
                    );
                })}
            </ButtonGroup>
            {activeType === "admin" && (
                <Box sx={{ mb: 3, textAlign: 'right' }}>
                    <Button
                        variant="contained"
                        component="label"
                        startIcon={<UploadFileIcon />}
                        sx={{ backgroundColor: "#3f6f7a", textTransform: "none" }}
                    >
                        Upload Document
                        <input
                            type="file"
                            hidden
                            accept="application/pdf,image/*,.docx,.doc"
                            onChange={async (e) => {
                                const file = e.target.files[0];
                                if (!file) return;

                                const formData = new FormData();
                                formData.append("file", file);
                                formData.append("client_id", client.client_id);

                                try {
                                    await fetch(process.env.REACT_APP_DOCUMENTS_ADMINUPLOAD, {
                                        method: "POST",
                                        body: formData,
                                        credentials: "include",
                                    });

                                    alert("Uploaded successfully");
                                    window.location.reload();
                                } catch {
                                    alert("Upload failed");
                                }
                            }}
                        />
                    </Button>
                </Box>
            )}

            {/* DOCUMENT CARDS */}
            {filteredDocs.length === 0 ? (
                <Typography color="text.secondary">
                    No documents available
                </Typography>
            ) : (
                <Grid container spacing={2}>
                    {filteredDocs.map((doc) => (
                        <Grid item xs={12} sm={6} md={4} key={doc.id}>
                            <Card
                                elevation={3}
                                sx={{
                                    height: "100%",
                                    display: "flex",
                                    flexDirection: "column",
                                }}
                            >
                                <CardContent sx={{ flexGrow: 1 }}>
                                    <Box
                                        sx={{
                                            display: "flex",
                                            alignItems: "center",
                                            mb: 1,
                                        }}
                                    >
                                        <FolderIcon
                                            sx={{ mr: 1, color: "#3f6f7a" }}
                                        />

                                        <Typography variant="subtitle1" noWrap>
                                            {doc.file_name}
                                        </Typography>
                                    </Box>

                                    {/* <Chip
                    label={doc.uploaded_by.toUpperCase()}
                    color={roleColor[doc.uploaded_by]}
                    size="small"
                    sx={{ mb: 1 }}
                  /> */}

                                    {/* <Typography variant="body2" color="text.secondary">
                    Uploaded by {doc.uploaded_by_name}
                  </Typography> */}

                                    <Typography variant="caption" color="text.secondary">
                                        {new Date(doc.uploaded_at).toLocaleString()}
                                    </Typography>
                                </CardContent>

                                <CardActions sx={{ justifyContent: "flex-end" }}>
                                   <IconButton
                                        disabled={loadingDocId === doc.id}
                                        onClick={() => handleViewClick(doc)}
                                    >
                                        <VisibilityIcon />
                                    </IconButton>


                                    {/* <IconButton
                                        component="a"
                                        href={`${process.env.REACT_APP_URL}/api/documents/${doc.id}`}
                                        target="_self"
                                    >
                                        <DownloadIcon />
                                    </IconButton> */}


                                    {(doc.uploaded_by === "admin" ||
                                        doc.uploaded_by === "staff") && (
                                            <IconButton
                                                color="error"
                                                onClick={async () => {
                                                    if (!window.confirm("Delete this document?")) return;

                                                    try {
                                                        await fetch(`${process.env.REACT_APP_DOCUMENTS_ADMINDELETE}/${doc.id}`, {
                                                            method: "DELETE",
                                                            credentials: "include",
                                                        });

                                                        alert("Document deleted");
                                                        window.location.reload();
                                                    } catch {
                                                        alert("Delete failed");
                                                    }
                                                }}
                                            >
                                                <DeleteIcon />
                                            </IconButton>
                                        )}
                                </CardActions>

                            </Card>
                        </Grid>
                    ))}
                </Grid>
            )}


<Dialog
    open={otpSendingSkeleton}
    maxWidth="xs"
    fullWidth
>
    <DialogContent>

        <Box
            sx={{
                p:3,
                display:"flex",
                flexDirection:"column",
                alignItems:"center"
            }}
        >

            {/* Icon Skeleton */}
            <Skeleton
                variant="circular"
                width={55}
                height={55}
                sx={{
                    mb:2
                }}
            />


            {/* Title Skeleton */}
            <Skeleton
                variant="text"
                width="60%"
                height={35}
            />


            {/* Description Skeleton */}
            <Skeleton
                variant="text"
                width="90%"
                height={25}
            />

            <Skeleton
                variant="text"
                width="70%"
                height={25}
            />


            {/* OTP Input Skeleton */}
            <Skeleton
                variant="rounded"
                width="100%"
                height={55}
                sx={{
                    mt:3,
                    borderRadius:2
                }}
            />


            {/* Buttons Skeleton */}
            <Box
                sx={{
                    width:"100%",
                    display:"flex",
                    justifyContent:"flex-end",
                    gap:2,
                    mt:3
                }}
            >

                <Skeleton
                    variant="rounded"
                    width={80}
                    height={36}
                />

                <Skeleton
                    variant="rounded"
                    width={90}
                    height={36}
                />

            </Box>


        </Box>

    </DialogContent>

</Dialog>

<Dialog
    open={otpDialog}
    onClose={() => setOtpDialog(false)}
    maxWidth="xs"
    fullWidth
>

    <DialogContent sx={{ p: 3 }}>

        <Typography
            variant="h6"
            gutterBottom
        >
            OTP Verification
        </Typography>

        <Typography
            variant="body2"
            color="text.secondary"
            sx={{ mb: 2 }}
        >
            Enter the OTP sent to the patient's email.
        </Typography>

        <TextField

            fullWidth

            label="OTP"

            value={otp}

            onChange={(e) => setOtp(e.target.value)}

            inputProps={{
                maxLength: 6
            }}

        />

        <Box

            mt={3}

            display="flex"

            justifyContent="flex-end"

            gap={2}

        >

            <Button

                onClick={() => setOtpDialog(false)}

            >

                Cancel

            </Button>

            <Button

                variant="contained"

                sx={{
                    backgroundColor: "#3f6f7a"
                }}

                disabled={verifyingOtp}

                onClick={verifyOtp}

            >

                {

                    verifyingOtp

                        ?

                        <CircularProgress
                            size={20}
                            color="inherit"
                        />

                        :

                        "Verify"

                }

            </Button>

        </Box>

    </DialogContent>

</Dialog>


     <Dialog
    open={approvalDialog}
    onClose={() => setApprovalDialog(false)}
    maxWidth="sm"
    fullWidth
>
    <DialogContent sx={{ p: 4 }}>

        <Box sx={{ textAlign: "center" }}>
            <VisibilityIcon
                sx={{
                    fontSize: 60,
                    color: "#3f6f7a",
                    mb: 2,
                }}
            />

            <Typography
                variant="h6"
                fontWeight={600}
                gutterBottom
            >
                Patient Approval Required
            </Typography>

            <Typography
                color="text.secondary"
                sx={{ mb: 3 }}
            >
                This document can only be viewed after receiving
                approval from the patient.
            </Typography>

            {selectedDoc && (
                <Card
                    variant="outlined"
                    sx={{
                        mb: 3,
                        textAlign: "left",
                        borderRadius: 2,
                    }}
                >
                    <CardContent>
                        <Typography
                            variant="subtitle2"
                            color="text.secondary"
                        >
                            Document
                        </Typography>

                        <Typography fontWeight={600}>
                            {selectedDoc.file_name}
                        </Typography>
                    </CardContent>
                </Card>
            )}

            <Box
                sx={{
                    bgcolor: "#f5f5f5",
                    p: 2,
                    borderRadius: 2,
                    textAlign: "left",
                    mb: 3,
                }}
            >
                <Typography variant="body2">
                    • A request will be sent to the patient.
                </Typography>

                <Typography variant="body2">
                    • The patient can approve or reject your request.
                </Typography>

                <Typography variant="body2">
                    • You'll be able to view the document after approval.
                </Typography>
            </Box>

            <Box
                sx={{
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: 2,
                }}
            >
                <Button
                    onClick={() => setApprovalDialog(false)}
                >
                    Cancel
                </Button>

                <Button
                    variant="contained"
                    sx={{
                        backgroundColor: "#3f6f7a",
                        textTransform: "none",
                    }}
                    onClick={async () => {
                        try {
                            const res = await fetch(
                                `${process.env.REACT_APP_REQUEST_ACCESS}/${selectedDoc.id}`,
                                {
                                    method: "POST",
                                    credentials: "include",
                                }
                            );

                            const data = await res.json();

                            alert(data.message);

                            setApprovalDialog(false);

                        } catch {
                            alert("Failed to send request.");
                        }
                    }}
                >
                    Request Permission
                </Button>
            </Box>
        </Box>

    </DialogContent>
</Dialog>

            {/* PREVIEW MODAL */}
            <Dialog
                open={Boolean(previewFile)}
                onClose={() => setPreviewFile(null)}
                fullWidth
                maxWidth="lg"
            >
                <DialogContent sx={{ height: "80vh", p: 0 }}>
                    {previewFile && (
                        <iframe
                            src={getPreviewSrc(previewFile)}
                            title="Document Preview"
                            width="100%"
                            height="100%"
                            style={{ border: "none" }}
                        />
                    )}
                </DialogContent>
            </Dialog>

            {/* IN-PAGE DOCUMENT VIEWER (replaces window.open new-tab behavior) */}
           {/* IN-PAGE DOCUMENT VIEWER */}
<Dialog
    open={docViewerOpen}
    onClose={closeDocViewer}
    maxWidth={false}
    PaperProps={{
        sx: {
            width: {
                xs: "95vw",
                sm: "80vw",
                md: "65vw",
            },
            height: {
                xs: "90vh",
                sm: "85vh",
                md: "85vh",
            },
            margin: "auto",
            borderRadius: 3,
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
        },
    }}
>

    {/* HEADER */}
    <Box
        sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            px: 2,
            py: 1,
            borderBottom: "1px solid #ddd",
            backgroundColor: "#fff",
        }}
    >

        <Typography fontWeight={600}>
            Document Preview
        </Typography>


        <IconButton onClick={closeDocViewer}>
            ✕
        </IconButton>

    </Box>


    {/* DOCUMENT CONTENT */}
    <DialogContent
        sx={{
            p:0,
            flex:1,
            overflow:"hidden",
            backgroundColor:"#f5f5f5",
        }}
    >

        {docViewerUrl && (

            <iframe
                src={`${docViewerUrl}#toolbar=0&navpanes=0&scrollbar=0`}
                title="Document Viewer"
                width="100%"
                height="100%"
                style={{
                    border:"none",
                }}
            />

        )}

    </DialogContent>

</Dialog>

        </>
    );
}

export default ClientDocuments;