import React,{
useState,useEffect
} from "react";
import ClientPrefill from "./ClientPrefill";
import {getClient} from "./formApi";

import {
submitForm
}
from "./formApi";

import "./DynamicForm.css";


/*
  WHAT CHANGED (this pass):

  Same rendering logic as before (sections, doctorOnly filtering,
  all field types) but now uses DynamicForm.css instead of inline
  styles, so the form:

    - Looks like a real card-based clinic form instead of a plain box.
    - Lays fields out in a 2-column grid on tablet/desktop, 1 column
      on mobile (df-field-grid, see CSS file).
    - Gives "wide" field types (textarea, paragraph, checkbox/radio
      groups, tables) their own full-width row via df-field-full,
      even inside the 2-column grid, so long content never gets
      squeezed into a half-width column.
    - Keeps the submit button full-width and easy to tap on mobile,
      auto-sizing on larger screens.
*/

// Field types that should always span the full row width, even in
// the 2-column grid — anything with potentially long content or a
// list of options.
const FULL_WIDTH_TYPES = [
  "textarea",
  "paragraph",
  "radio",
  "checkbox",
  "yes_no",
  "table",
  "file"
];


const DynamicForm=({form, onSubmitted}) => {


console.log("FORM PROP RECEIVED",form);


const [data,setData]=useState({});
const [client,setClient]=useState(null);

useEffect(()=>{


if(form.client_id)
{


getClient(form.client_id)

.then(res=>{

setClient(res.data);

});


}


},[]);


// Simple fields: text, number, date, textarea, select, radio, yes_no, signature
const handleChange=(e)=>{


const {

name,

value

}=e.target;



setData(prev=>({

...prev,

[name]: value

}));


};


// Checkbox GROUP: toggles one option in/out of an array for that field name
const handleCheckboxGroupChange=(fieldName,option,checked)=>{

setData(prev=>{

const existing = Array.isArray(prev[fieldName]) ? prev[fieldName] : [];

const updated = checked
  ? [...existing, option]
  : existing.filter(o => o !== option);

return {
  ...prev,
  [fieldName]: updated
};

});

};


// Legacy single boolean checkbox (no options array on the field)
const handleSingleCheckboxChange=(fieldName,checked)=>{

setData(prev=>({

...prev,

[fieldName]: checked

}));

};




const handleSubmit=async()=>{


    console.log("SUBMIT DATA",{
    admin_id:form.admin_id,
    form_id:form.id,
    form_type:form.form_type,
    data:data
});

try{


await submitForm({

admin_id: form.admin_id,

form_id: form.id,

form_type: form.form_type,

data: data

});


alert(
"Submitted Successfully"
);


// Reset all fields so the form is blank if the same page is ever
// reused, then hand control back to the parent to redirect.
setData({});


if(onSubmitted){

  onSubmitted();

}



}
catch(err){

console.log(err);

alert(
"Submission failed"
);


}



};



// Renders a single field's INPUT ONLY (label is rendered by the caller).
// Returns null for doctorOnly fields, since patients shouldn't see them.
const renderField=(field)=>{


if(field.doctorOnly){

return null;

}


switch(field.type){


case "paragraph":

  return(
    <p className="df-paragraph">
      {field.description || field.label}
    </p>
  );


case "textarea":

  return(
    <textarea
      className="df-textarea"
      name={field.name}
      placeholder={field.placeholder || ""}
      onChange={handleChange}
    />
  );


case "number":

  return(
    <input
      className="df-input"
      type="number"
      name={field.name}
      placeholder={field.placeholder || ""}
      onChange={handleChange}
    />
  );


case "date":

  return(
    <input
      className="df-input"
      type="date"
      name={field.name}
      onChange={handleChange}
    />
  );


case "radio":

  return(
    <div className="df-option-group">
      {
        (field.options || []).map((option,idx)=>(
          <label key={idx} className="df-option-row">
            <input
              type="radio"
              name={field.name}
              value={option}
              onChange={handleChange}
            />
            {option}
          </label>
        ))
      }
    </div>
  );


case "yes_no":

  return(
    <div className="df-yesno-row">
      <label className="df-option-row">
        <input
          type="radio"
          name={field.name}
          value="Yes"
          onChange={handleChange}
        />
        Yes
      </label>
      <label className="df-option-row">
        <input
          type="radio"
          name={field.name}
          value="No"
          onChange={handleChange}
        />
        No
      </label>
    </div>
  );


case "select":

  return(
    <select
      className="df-select"
      name={field.name}
      defaultValue=""
      onChange={handleChange}
    >
      <option value="" disabled>Select…</option>
      {
        (field.options || []).map((option,idx)=>(
          <option key={idx} value={option}>{option}</option>
        ))
      }
    </select>
  );


case "checkbox":

  if(Array.isArray(field.options) && field.options.length > 0){

    const selected = Array.isArray(data[field.name]) ? data[field.name] : [];

    return(
      <div className="df-option-group">
        {
          field.options.map((option,idx)=>(
            <label key={idx} className="df-option-row">
              <input
                type="checkbox"
                checked={selected.includes(option)}
                onChange={(e)=>
                  handleCheckboxGroupChange(field.name,option,e.target.checked)
                }
              />
              {option}
            </label>
          ))
        }
      </div>
    );

  }

  return(
    <label className="df-option-row" style={{display:"inline-flex",width:"auto"}}>
      <input
        type="checkbox"
        checked={!!data[field.name]}
        onChange={(e)=>handleSingleCheckboxChange(field.name,e.target.checked)}
      />
      {field.label}
    </label>
  );


case "signature":

  return(
    <input
      className="df-input"
      type="text"
      name={field.name}
      placeholder="Type your full name to sign"
      onChange={handleChange}
    />
  );


case "file":

  return(
    <input
      className="df-input"
      type="file"
      name={field.name}
      disabled
    />
  );


case "table":

  return(
    <p className="df-placeholder-note">
      (Table field — not yet supported for patient entry)
    </p>
  );


case "text":
default:

  return(
    <input
      className="df-input"
      type="text"
      name={field.name}
      placeholder={field.placeholder || ""}
      onChange={handleChange}
    />
  );


}


};



const sections = Array.isArray(form.sections) ? form.sections : [];

if(sections.length === 0){

return(

<div className="df-page">
  <div className="df-card">
    <div className="df-empty">
      <h2>{form.form_name || "Form"}</h2>
      <p>This form has no fields configured, or the field data is invalid.</p>
    </div>
  </div>
</div>

);

}



return(

<div className="df-page">
<div className="df-card">


<div className="df-header">
  <h2>{form.form_name}</h2>
  {form.description && <p>{form.description}</p>}
</div>


<div className="df-body">

{

sections.map((section,sectionIdx)=>(

<div key={sectionIdx} className="df-section">

<div className="df-section-header">
  <span className="df-section-badge">{sectionIdx + 1}</span>
  <h3 className="df-section-title">{section.title}</h3>
</div>


<div className="df-field-grid">

{

(section.fields || [])

.filter(field => !field.doctorOnly)

.map((field,fieldIdx)=>{

const isFullWidth =
  FULL_WIDTH_TYPES.includes(field.type) ||
  (field.type === "checkbox" && !(field.options && field.options.length));

return(

<div
  key={field.name || fieldIdx}
  className={
    isFullWidth
      ? "df-field df-field-full"
      : "df-field"
  }
>

{

field.type !== "paragraph" &&
!(field.type === "checkbox" && !(field.options && field.options.length)) &&

<span className="df-label">
  {field.label}
  {field.required && <span className="df-required">*</span>}
</span>

}


{renderField(field)}


</div>

);

})

}


</div>


</div>

))

}

</div>


<div className="df-submit-bar">
  <button className="df-submit-btn" onClick={handleSubmit}>
    Submit
  </button>
</div>


</div>
</div>


);


};


export default DynamicForm;