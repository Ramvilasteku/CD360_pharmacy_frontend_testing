import React,{useEffect,useState} from "react";

import {
useParams,
useNavigate
} from "react-router-dom";


import {
getFormById
} from "./formApi";


import DynamicForm from "./DynamicForm";



const SingleFormPage=()=>{


const {token,admin_id,form_id}=useParams();

const navigate=useNavigate();


const [form,setForm]=useState(null);


const [loading,setLoading]=useState(true);


const [error,setError]=useState(null);



useEffect(()=>{


loadForm();


},[]);



const loadForm=async()=>{


try{


const res=await getFormById(admin_id,form_id);


setForm(res.data);


}
catch(err){

console.log(err);

setError(
  err.response?.data?.message ||
  err.message ||
  "Unknown error"
);

}

finally{

setLoading(false);

}


};


// Called by DynamicForm after a successful submit. Sends the patient
// back to the "Select a Form" list for this same QR token, so they
// can fill out another form if needed (e.g. registration, then consent).
const handleSubmitted=()=>{

navigate(`/forms/${token}`);

};



if(loading)
return <h2>Loading...</h2>;


if(error)
return <h2>{error}</h2>;


if(!form)
return <h2>Form not found</h2>;



return(

<DynamicForm

form={form}

onSubmitted={handleSubmitted}

/>

);


};


export default SingleFormPage;