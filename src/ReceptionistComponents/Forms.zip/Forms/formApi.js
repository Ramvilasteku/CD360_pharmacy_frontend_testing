import axios from "axios";


const API = axios.create({

    baseURL:"http://192.168.1.11:5000/api",

    withCredentials:true

});


export const getFormById = (adminId, formId) => {
  return API.get(`/forms/${adminId}/${formId}`);
};



// Get form using QR token

export const getFormByQR = (token)=>{

    return API.get(
        `/forms/qr/${token}`
    );

};



// Submit form

export const submitForm = (data)=>{

    return API.post(
        "/forms/submit",
        data
    );

};



// Get client details

export const getClient = (clientId)=>{

    return API.get(
        `/clients/${clientId}`
    );

};


export default API;