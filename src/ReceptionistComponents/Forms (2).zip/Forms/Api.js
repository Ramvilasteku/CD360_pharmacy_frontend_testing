import axios from "axios";

/*
  REACT_APP_QR_API_URL is the only base URL this module reads.

  Not REACT_APP_API_URL — that belongs to the IPD backend on port 5001.
  Not REACT_APP_FORM_MODULE_API_URL — left on localhost for whatever else
  still reads it. Both it and REACT_APP_QR_API_URL point at the same
  server (port 5000); the QR one just uses the LAN address so phones
  scanning the code can actually reach it.

  CRA inlines process.env.REACT_APP_* at BUILD time, not run time —
  editing .env requires a dev-server restart (or a rebuild) to take effect.
*/
const BASE_URL = process.env.REACT_APP_QR_API_URL || "/api";

if (process.env.NODE_ENV === "development" && !process.env.REACT_APP_QR_API_URL) {
  console.warn(
    "REACT_APP_QR_API_URL is not set. Falling back to /api — requests will hit the dev server, not the backend."
  );
}

const API = axios.create({
  baseURL: BASE_URL,
  withCredentials: true,
});

/* ---------- QR (admin side) ---------- */

// The clinic's own QR code, if one has been generated
export const getMyQR = () => API.get("/qr/my-qr");

// Create the clinic's QR code
export const generateQR = () => API.post("/qr/generate", {});

/* ---------- Forms (patient side) ---------- */

// Get one form's schema
export const getFormById = (adminId, formId) => {
  return API.get(`/forms/${adminId}/${formId}`);
};

// Get the clinic's form list from a QR token
export const getFormByQR = (token) => {
  return API.get(`/forms/qr/${token}`);
};

/*
  Look up an existing patient for prefill, scoped to the clinic that owns
  this QR token. Replaces getClient(clientId), which hit /clients/:id —
  an admin endpoint that returns the whole row, and would have needed to
  be public for a patient to call it.
*/
export const lookupClient = (token, { client_id, mobile }) => {
  return API.post(`/forms/qr/${token}/client`, { client_id, mobile });
};

/*
  Submit. Note there is no admin_id: the server derives it from qr_token
  and stores it on the submission, so it cannot be spoofed or arrive null.
*/
export const submitForm = (payload) => {
  return API.post("/forms/submit", payload);
};

export default API;