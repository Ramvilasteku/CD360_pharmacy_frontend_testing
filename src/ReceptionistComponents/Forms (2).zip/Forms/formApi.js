import axios from "axios";


/*
  The base URL was hardcoded to a LAN address ("http://192.168.1.11:5000/api").
  That works on the dev machine and nowhere else — and this is the one
  part of the module that runs on patients' phones over the internet.
*/
const API = axios.create({

    baseURL:
        (process.env.REACT_APP_FORM_MODULE_API_URL ||
         process.env.REACT_APP_API_URL ||
         "/api"),

    withCredentials: true

});


// Get one form's schema
export const getFormById = (adminId, formId) => {
  return API.get(`/forms/${adminId}/${formId}`);
};


// Get the clinic's form list from a QR token
export const getFormByQR = (token) => {
    return API.get(`/forms/qr/${token}`);
};


/*
  Look up an existing patient for prefill, scoped to the clinic that owns
  this QR token. Replaces getClient(clientId), which hit /clients/:id —
  an admin endpoint that returns the whole row, and would have needed to
  be public for a patient to call it.
*/
export const lookupClient = (token, { client_id, mobile }) => {
    return API.post(`/forms/qr/${token}/client`, { client_id, mobile });
};


/*
  Submit. Note there is no admin_id: the server derives it from qr_token
  and stores it on the submission, so it cannot be spoofed or arrive null.
*/
export const submitForm = (payload) => {
    return API.post("/forms/submit", payload);
};


export default API;