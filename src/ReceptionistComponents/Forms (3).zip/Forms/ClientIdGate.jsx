/*
====================================================================
ClientIdGate.jsx

Shown before any non-registration form. The patient enters the Client
ID reception gave them plus their registered mobile number; on a match
the clinic's record is loaded and handed to DynamicForm, which prefills
the basic fields and asks only for the rest.

WHY THE MOBILE NUMBER TOO
-------------------------
A client id is a small integer. With the id alone, anyone holding a QR
link could type 1, 2, 3... and read back real patients' names and phone
numbers. Requiring the mobile turns it into something the person has to
already know. The server enforces this (see REQUIRE_MOBILE_MATCH in
form.controller.js) — this screen just collects it.

Registration forms never reach this screen: there is no client yet,
which is the point of registering.
====================================================================
*/

import React, { useState } from "react";

import { lookupClient } from "./formApi";

import "./DynamicForm.css";

const ClientIdGate = ({ token, formName, onResolved }) => {

    const [clientId, setClientId] = useState("");
    const [mobile, setMobile] = useState("");
    const [checking, setChecking] = useState(false);
    const [error, setError] = useState("");

    const submit = async (e) => {
        if (e) e.preventDefault();

        if (!clientId.trim()) {
            setError("Please enter your Client ID.");
            return;
        }

        try {
            setChecking(true);
            setError("");

            const res = await lookupClient(token, {
                client_id: clientId.trim(),
                mobile: mobile.trim()
            });

            onResolved(res.data.client);

        } catch (err) {
            console.log("Client lookup failed", err);
            setError(
                err.response?.data?.message ||
                "Could not verify those details. Please check with reception."
            );
        } finally {
            setChecking(false);
        }
    };

    return (
        <div className="df-page">
            <div className="df-card">

                <div className="df-header">
                    <h2>{formName || "Patient form"}</h2>
                    <p>Enter your details to load this form.</p>
                </div>

                <form className="df-body" onSubmit={submit}>
                    <div className="df-section">
                        <div className="df-field-grid">

                            <div className="df-field">
                                <span className="df-label">
                                    Client ID<span className="df-required">*</span>
                                </span>
                                <input
                                    className="df-input"
                                    inputMode="numeric"
                                    autoComplete="off"
                                    value={clientId}
                                    onChange={(e) => setClientId(e.target.value)}
                                    placeholder="e.g. 1042"
                                />
                            </div>

                            <div className="df-field">
                                <span className="df-label">
                                    Registered mobile number<span className="df-required">*</span>
                                </span>
                                <input
                                    className="df-input"
                                    inputMode="tel"
                                    autoComplete="tel"
                                    value={mobile}
                                    onChange={(e) => setMobile(e.target.value)}
                                    placeholder="10-digit number"
                                />
                            </div>

                        </div>

                        {error && (
                            <p style={{ color: "#c0392b", marginTop: 12 }}>{error}</p>
                        )}

                        <p style={{ color: "#7c8a8d", fontSize: 13, marginTop: 12 }}>
                            Don’t have a Client ID? Please complete the registration form
                            first, or ask at the reception desk.
                        </p>
                    </div>

                    <div className="df-submit-bar">
                        <button
                            className="df-submit-btn"
                            type="submit"
                            disabled={checking}
                        >
                            {checking ? "Checking…" : "Continue"}
                        </button>
                    </div>
                </form>

            </div>
        </div>
    );
};

export default ClientIdGate;