import React from "react";


const ClientPrefill=({client})=>{


return(

<div>


<h3>
Patient Details
</h3>


<label>
Name
</label>

<input

value={client.name || ""}

readOnly

/>


<br/>


<label>
Mobile
</label>

<input

value={client.mobile || ""}

readOnly

/>


<br/>


<label>
Gender
</label>

<input

value={client.gender || ""}

readOnly

/>


<br/>


<label>
DOB
</label>


<input

value={client.dob || ""}

readOnly

/>


</div>

);


};


export default ClientPrefill;