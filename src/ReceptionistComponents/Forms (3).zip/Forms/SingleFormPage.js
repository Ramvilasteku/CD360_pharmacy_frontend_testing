import React, { useEffect, useState } from "react";

import { useParams, useNavigate } from "react-router-dom";

import { getFormById } from "./formApi";

import DynamicForm from "./DynamicForm";
import ClientIdGate from "./ClientIdGate";


/*
  Registration vs everything else:

    form_type === "registration"
        -> no client exists yet; the patient fills the form and
           submitForm() creates (or tops up) the clients row.

    anything else
        -> ClientIdGate first. The patient enters their Client ID and
           registered mobile, we load their record, and DynamicForm
           prefills the basic fields and asks only for the rest.

  The QR token is passed down to DynamicForm because the server reads
  admin_id from it at submit time.
*/
const SingleFormPage = () => {

    const { token, admin_id, form_id } = useParams();
    const navigate = useNavigate();

    const [form, setForm] = useState(null);
    const [client, setClient] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        let cancelled = false;

        (async () => {
            try {
                const res = await getFormById(admin_id, form_id);
                if (!cancelled) setForm(res.data);
            } catch (err) {
                console.log(err);
                if (!cancelled) {
                    setError(
                        err.response?.data?.message || err.message || "Unknown error"
                    );
                }
            } finally {
                if (!cancelled) setLoading(false);
            }
        })();

        return () => {
            cancelled = true;
        };
    }, [admin_id, form_id]);

    // After a successful submit, back to the form list for this same QR
    // token so the patient can fill another one (registration, then consent).
    const handleSubmitted = () => navigate(`/forms/${token}`);

    if (loading) return <h2>Loading...</h2>;

    if (error) return <h2>{error}</h2>;

    if (!form) return <h2>Form not found</h2>;

    const needsClient = form.form_type !== "registration";

    if (needsClient && !client) {
        return (
            <ClientIdGate
                token={token}
                formName={form.form_name}
                onResolved={setClient}
            />
        );
    }

    return (
        <DynamicForm
            form={form}
            client={client}
            qrToken={token}
            onSubmitted={handleSubmitted}
        />
    );
};

export default SingleFormPage;