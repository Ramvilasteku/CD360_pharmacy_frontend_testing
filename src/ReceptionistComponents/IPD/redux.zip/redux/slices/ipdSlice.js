import { createSlice } from "@reduxjs/toolkit";

const ipdSlice = createSlice({
  name: "ipd",
  initialState: {
    dischargedPatients: {}, // { IPD001: true, IPD002: true }
  },
  reducers: {
    setDischargedPatients: (state, action) => {
      state.dischargedPatients = action.payload;
    },

    addDischargedPatient: (state, action) => {
      state.dischargedPatients[action.payload] = true;
    },

    removeDischargedPatient: (state, action) => {
      delete state.dischargedPatients[action.payload];
    },
  },
});

export const {
  setDischargedPatients,
  addDischargedPatient,
  removeDischargedPatient,
} = ipdSlice.actions;

export default ipdSlice.reducer;