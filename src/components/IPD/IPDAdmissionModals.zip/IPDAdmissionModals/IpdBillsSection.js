import React, {
  useCallback,
  useEffect,
  useState,
} from "react";

import axios from "axios";

import {
  Box,
  Typography,
} from "@mui/material";

import { DataGrid } from "@mui/x-data-grid";

const API = process.env.REACT_APP_URL_IPD;

export default function IpdBillsSection({
  ipdId,
}) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] =
    useState(true);

  const fetchBills =
    useCallback(async () => {
      try {
        setLoading(true);

        const res = await axios.get(
          `${API}/api/getall/bills`,
          {
            params: {
              ipd_id: ipdId,
            },
            withCredentials: true,
          }
        );

        const data =
          res.data.data || [];

        const formatted =
          data.map((item) => ({
            id: item.bill_summary.id,

            ipd_id:
              item.bill_summary.ipd_id,

            total_amount:
              item.bill_summary
                .total_amount,

            discount:
              item.bill_summary
                .discount,

            paid_amount:
              item.bill_summary
                .paid_amount,

            balance_amount:
              item.bill_summary
                .balance_amount,

            bill_status:
              item.bill_summary
                .bill_status,

            created_at:
              item.bill_summary
                .created_at,
          }));

        setRows(formatted);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }, [ipdId]);

  useEffect(() => {
    fetchBills();
  }, [fetchBills]);

  const formatDate = (value) => {
    if (!value) return "—";

    return new Date(value)
      .toLocaleDateString("en-IN");
  };

  const columns = [
    {
      field: "id",
      headerName: "Bill ID",
      width: 120,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "total_amount",
      headerName: "Total",
      width: 140,
      align: "center",
      headerAlign: "center",

      renderCell: (params) => (
        <Typography fontWeight={700}>
          ₹{params.value}
        </Typography>
      ),
    },

    {
      field: "discount",
      headerName: "Discount",
      width: 120,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "paid_amount",
      headerName: "Paid",
      width: 120,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "balance_amount",
      headerName: "Balance",
      width: 130,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "bill_status",
      headerName: "Status",
      width: 130,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "created_at",
      headerName: "Date",
      width: 140,
      align: "center",
      headerAlign: "center",

      renderCell: (params) =>
        formatDate(params.value),
    },
     {
      field: "created_at",
      headerName: "Created Date",
      headerAlign: "center",
      align: "center",
      flex: 0.6,
      minWidth: 100,

      renderCell: (params) =>
        new Date(params.row.created_at).toLocaleDateString(),
    },

    {
      field: "updated_at",
      headerName: "Updated Date",
      flex: 0.6,
      headerAlign: "center",
      align: "center",
      minWidth: 100,

      renderCell: (params) =>
        new Date(params.row.updated_at).toLocaleDateString(),
    },
  ];

  if (!loading && rows.length === 0) {
  return null;
}
return (
    <Box
      sx={{
        mt: 3,
        borderRadius: 3,
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          px: 3,
          py: 2, color: "#3F6F7A",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <Typography
          variant="h6"
          fontWeight={700}
        >
          Bills
        </Typography>
      </Box>

      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
       autoHeight
        pageSizeOptions={[5, 10]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        disableRowSelectionOnClick
        sx={{
          border: "none",

          backgroundColor: "transparent",

          "& .MuiDataGrid-main": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-row": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-cell": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#f1f5f9",
          },

          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: 700,
          },
          "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
            {
              marginTop: "0px",
              marginBottom: "0px",
            },
          "& .MuiDataGrid-cell": {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          },
        }}
      />
    </Box>
  );
}