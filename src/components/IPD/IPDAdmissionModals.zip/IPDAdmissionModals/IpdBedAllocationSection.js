import React, { useCallback, useEffect, useState } from "react";

import axios from "axios";

import { Box, Typography, Chip } from "@mui/material";

import { DataGrid } from "@mui/x-data-grid";

import "./IpdBedAllocationSection.css";

const API = process.env.REACT_APP_URL_IPD;

export default function IpdBedAllocationSection({ ipdId }) {
  const [rows, setRows] = useState([]);

  const [loading, setLoading] = useState(true);

  // =========================================
  // FETCH DATA
  // =========================================

  const fetchAllocations = useCallback(async () => {
    try {
      setLoading(true);

      const res = await axios.get(`${API}/api/getall/allocated-beds`, {
        withCredentials: true,
      });

      const all = res.data.data || [];
      const filtered = all.filter((r) => String(r.ipd_id) === String(ipdId));

      setRows(filtered);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [ipdId]);

  useEffect(() => {
    fetchAllocations();
  }, [fetchAllocations]);

  // =========================================
  // DATE FORMAT
  // =========================================

  const formatDate = (value) => {
    if (!value) return "—";

    return new Date(value).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // =========================================
  // DATAGRID COLUMNS
  // =========================================

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 90,
      headerAlign: "center",
      align: "center",
    },

    {
      field: "bed_id",
      headerName: "Bed ID",
      width: 120,
      headerAlign: "center",
      align: "center",
    },

    {
      field: "bed_number",
      headerName: "Bed Number",
      width: 140,
      headerAlign: "center",
      align: "center",

      renderCell: (params) => (
        <Typography fontWeight={600}>{params.value || "—"}</Typography>
      ),
    },

    {
      field: "start_time",
      headerName: "Start Time",
      width: 240,
      headerAlign: "center",
      align: "center",

      renderCell: (params) => (
        <Typography>{formatDate(params.value)}</Typography>
      ),
    },

    {
      field: "end_time",
      headerName: "End Time",
      width: 240,
      headerAlign: "center",
      align: "center",

      renderCell: (params) => (
        <Typography>{formatDate(params.value)}</Typography>
      ),
    },

    {
      field: "allocation_status",
      headerName: "Status",
      width: 150,
      headerAlign: "center",
      align: "center",

      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === "active" ? "success" : "primary"}
          size="small"
          sx={{
            textTransform: "capitalize",
            fontWeight: 600,
          }}
        />
      ),
    },

    {
      field: "created_at",
      headerName: "Created Date",
      headerAlign: "center",
      align: "center",
      flex: 0.6,
      minWidth: 100,

      renderCell: (params) =>
        params.row.created_at
          ? new Date(params.row.created_at).toLocaleDateString()
          : "—",
    },
  ];

  // =========================================
  // JSX
  // =========================================

  if (!loading && rows.length === 0) {
    return null;
  }

  return (
    <Box className="ipd-bedalloc-wrap">
      {/* HEADER */}
      <Box className="ipd-bedalloc-header">
        <Typography variant="h6" fontWeight={700} component="div">
          Bed Allocation
        </Typography>
      </Box>

      {/* TABLE */}
      <Box className="ipd-bedalloc-grid-box">
        <DataGrid
          rows={rows}
          columns={columns}
          loading={loading}
          autoHeight
          pageSizeOptions={[5, 10, 20]}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 5,
              },
            },
          }}
          disableRowSelectionOnClick
        />
      </Box>
    </Box>
  );
}