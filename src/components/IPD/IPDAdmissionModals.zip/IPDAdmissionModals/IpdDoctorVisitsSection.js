import React, { useCallback, useEffect, useState } from "react";

import axios from "axios";

import { Box, Paper, Typography } from "@mui/material";

import { DataGrid } from "@mui/x-data-grid";

const API = process.env.REACT_APP_URL_IPD;

export default function IpdDoctorVisitsSection({ ipdId }) {
  const [rows, setRows] = useState([]);

  const [loading, setLoading] = useState(true);

  const fetchVisits = useCallback(async () => {
    try {
      setLoading(true);

      const res = await axios.get(
        `${API}/api/get/doctor-visits/byipd/${ipdId}`,
        {
          withCredentials: true,
        },
      );

      setRows(Array.isArray(res.data) ? res.data : res.data.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [ipdId]);

  useEffect(() => {
    fetchVisits();
  }, [fetchVisits]);

  const formatDate = (value) => {
    if (!value) return "—";

    return new Date(value).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const columns = [
    {
      field: "id",
      headerName: "ID",
      headerAlign: "center",
      align: "center",
      width: 90,
    },

    {
      field: "doctor_name",
      headerName: "Doctor",
      headerAlign: "center",
      align: "center",
      width: 220,
    },

    {
      field: "visit_date",
      headerName: "Visit Date",
      headerAlign: "center",
      align: "center",
      width: 220,

      renderCell: (params) => (
        <Typography>{formatDate(params.value)}</Typography>
      ),
    },

    {
      field: "visit_notes",
      headerName: "Notes",
      flex: 1,
      headerAlign: "center",
      align: "center",
      minWidth: 400,

      renderCell: (params) => (
        <div
          style={{
            maxHeight: "60px",
            overflowY: "auto",
            overflowX: "hidden",
            whiteSpace: "normal",
            wordBreak: "break-word",
            width: "100%",
            padding: "1px",
          }}
        >
          {params.value}
        </div>
      ),
    },

    {
      field: "visit_charge",
      headerName: "Charge",
      headerAlign: "center",
      align: "center",
      width: 120,

      renderCell: (params) => (
        <Typography fontWeight={700} color="success.main">
          ₹{params.value}
        </Typography>
      ),
    },

    {
      field: "created_at",
      headerName: "Created Date",
      headerAlign: "center",
      align: "center",
    
      minWidth: 150,

      renderCell: (params) =>
        new Date(params.row.created_at).toLocaleDateString(),
    },
  ];

  if (!loading && rows.length === 0) {
  return null;
}
return (
    <Box
      sx={{
        mt: 3,

        borderRadius: 3,

        overflow: "hidden",

        background: "transparent",
      }}
    >
      <Box
        sx={{
          px: 3,
          py: 2,
          color: "#3F6F7A",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <Typography variant="h6" fontWeight={700}>
          Doctor Visits
        </Typography>
      </Box>

      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        pageSizeOptions={[5, 10]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        disableRowSelectionOnClick
        sx={{
          border: "none",

          backgroundColor: "transparent",

          "& .MuiDataGrid-main": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-row": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-cell": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#f1f5f9",
          },

          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: 700,
          },
          "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
            {
              marginTop: "0px",
              marginBottom: "0px",
            },
          "& .MuiDataGrid-cell": {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          },
        }}
      />
    </Box>
  );
}
