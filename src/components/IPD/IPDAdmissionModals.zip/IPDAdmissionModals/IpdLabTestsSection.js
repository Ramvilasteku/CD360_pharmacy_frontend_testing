import React, { useCallback, useEffect, useState } from "react";

import axios from "axios";

import { Box, Paper, Typography, Chip } from "@mui/material";

import { DataGrid } from "@mui/x-data-grid";

const API = process.env.REACT_APP_URL_IPD;

export default function IpdLabTestsSection({ ipdId }) {
  const [rows, setRows] = useState([]);

  const [loading, setLoading] = useState(true);

  const fetchTests = useCallback(async () => {
    try {
      setLoading(true);

      const res = await axios.get(`${API}/api/get/lab-tests/ipd/${ipdId}`, {
        withCredentials: true,
      });

      setRows(res.data.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [ipdId]);

  useEffect(() => {
    fetchTests();
  }, [fetchTests]);

  const formatDate = (value) => {
    if (!value) return "—";

    return new Date(value).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const columns = [
    {
      field: "id",
      headerName: "ID",
      headerAlign: "center",
      align: "center",
      width: 90,
    },

    {
      field: "test_name",
      headerName: "Test Name",
      flex: 1,
      headerAlign: "center",
      align: "center",
      minwidth: 200,
    },

    {
      field: "test_date",
      headerName: "Test Date",
      headerAlign: "center",
      align: "center",
      width: 220,

      renderCell: (params) => (
        <Typography>{formatDate(params.value)}</Typography>
      ),
    },

    {
      field: "result_status",
      headerName: "Status",
      headerAlign: "center",
      align: "center",
      width: 150,

      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === "completed" ? "success" : "warning"}
          size="small"
        />
      ),
    },

    {
      field: "test_charge",
      headerName: "Charge",
      headerAlign: "center",
      align: "center",
      width: 150,

      renderCell: (params) => (
        <Typography fontWeight={700} color="success.main">
          ₹{params.value}
        </Typography>
      ),
    },

       {
      field: "created_at",
      headerName: "Created Date",
      headerAlign: "center",
      align: "center",
      minWidth: 130,

      renderCell: (params) =>
        new Date(params.row.created_at).toLocaleDateString(),
    },
  ];

  
if (!loading && rows.length === 0) {
  return null;
}
return (
    <Box
      sx={{
        mt: 3,

        borderRadius: 3,

        overflow: "hidden",

        background: "transparent",
      }}
    >
      <Box
        sx={{
          px: 3,
          py: 2,
          color: "#3F6F7A",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <Typography variant="h6" fontWeight={700}>
          Lab Tests
        </Typography>
      </Box>

      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        pageSizeOptions={[5, 10]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        disableRowSelectionOnClick
        sx={{
          border: "none",

          backgroundColor: "transparent",

          "& .MuiDataGrid-main": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-row": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-cell": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#f1f5f9",
          },

          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: 700,
          },
          "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
            {
              marginTop: "0px",
              marginBottom: "0px",
            },
          "& .MuiDataGrid-cell": {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          },
        }}
      />
    </Box>
  );
}
