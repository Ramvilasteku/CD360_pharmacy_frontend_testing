import React, { useCallback, useEffect, useState } from "react";

import axios from "axios";

import { Box, Typography } from "@mui/material";

import { DataGrid } from "@mui/x-data-grid";

const API = process.env.REACT_APP_URL_IPD;

export default function IpdPharmacyIssuesSection({ ipdId }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchPharmacy = useCallback(async () => {
    try {
      setLoading(true);

      const res = await axios.get(`${API}/api/getall/pharmacy`, {
        params: {
          ipd_id: ipdId,
        },
        withCredentials: true,
      });

      setRows(res.data.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [ipdId]);

  useEffect(() => {
    fetchPharmacy();
  }, [fetchPharmacy]);

    const formatDate = (value) => {
    if (!value) return "—";

    return new Date(value).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 90,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "medicine_name",
      headerName: "Medicine",
      width: 220,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "quantity",
      headerName: "Qty",
      width: 100,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "unit_price",
      headerName: "Unit Price",
      width: 140,
      align: "center",
      headerAlign: "center",
    },

    {
      field: "total_price",
      headerName: "Total",
      width: 140,
      align: "center",
      headerAlign: "center",

      renderCell: (params) => (
        <Typography fontWeight={700}>₹{params.value}</Typography>
      ),
    },

    {
      field: "issue_date",
      headerName: "Issue Date",
      width: 200,
      align: "center",
      headerAlign: "center",

      renderCell: (params) => (
        <Typography>{formatDate(params.value)}</Typography>
      ),
    },

    {
      field: "created_at",
      headerName: "Created Date",
      headerAlign: "center",
      align: "center",
      flex: 0.6,
      minWidth: 100,

      renderCell: (params) =>
        new Date(params.row.created_at).toLocaleDateString(),
    },

    {
      field: "updated_at",
      headerName: "Updated Date",
      flex: 0.6,
      headerAlign: "center",
      align: "center",
      minWidth: 100,

      renderCell: (params) =>
        new Date(params.row.updated_at).toLocaleDateString(),
    },
  ];

  if (!loading && rows.length === 0) {
  return null;
}
return (
    <Box
      sx={{
        mt: 3,
        borderRadius: 3,
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          px: 3,
          py: 2, color: "#3F6F7A",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <Typography variant="h6" fontWeight={700}>
          Pharmacy Issues
        </Typography>
      </Box>

      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
          autoHeight
        pageSizeOptions={[5, 10]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        disableRowSelectionOnClick
        sx={{
          border: "none",

          backgroundColor: "transparent",

          "& .MuiDataGrid-main": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-row": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-cell": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#f1f5f9",
          },

          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: 700,
          },
          "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
            {
              marginTop: "0px",
              marginBottom: "0px",
            },
          "& .MuiDataGrid-cell": {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          },
        }}
      />
    </Box>
  );
}
