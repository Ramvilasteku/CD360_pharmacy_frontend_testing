import React, { useCallback, useEffect, useState } from "react";

import axios from "axios";

import { Box, Typography, Paper, CircularProgress } from "@mui/material";

import { DataGrid } from "@mui/x-data-grid";

const API = process.env.REACT_APP_URL_IPD;

export default function IpdBedChargesSection({ ipdId }) {
  const [rows, setRows] = useState([]);

  const [loading, setLoading] = useState(true);

  // =========================================
  // FETCH BED CHARGES
  // =========================================

  const fetchCharges = useCallback(async () => {
    try {
      setLoading(true);

      const res = await axios.get(`${API}/api/getall/bed-charges`, {
        params: {
          ipd_id: ipdId,
        },
        withCredentials: true,
      });

      setRows(res.data.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [ipdId]);

  useEffect(() => {
    fetchCharges();
  }, [fetchCharges]);

  // =========================================
  // DATAGRID COLUMNS
  // =========================================

  const columns = [
    {
      field: "id",
      headerName: "ID",
      headerAlign: "center",
      align: "center",
      width: 90,
    },

    {
      field: "charge_date",
      headerName: "Charge Date",
      headerAlign: "center",
      align: "center",
      width: 140,
    },

    {
      field: "bed_number",
      headerName: "Bed Number",
      headerAlign: "center",
      align: "center",
      width: 130,
    },

    {
      field: "charge_type",
      headerName: "Charge Type",
      headerAlign: "center",
      align: "center",
      width: 140,
    },

    {
      field: "hours_used",
      headerName: "Hours Used",
      headerAlign: "center",
      align: "center",
      width: 130,
    },

    {
      field: "rate_per_day",
      headerName: "Rate / Day",
      headerAlign: "center",
      align: "center",
      width: 140,

      renderCell: (params) => <Typography>₹{params.value}</Typography>,
    },

    {
      field: "charge_amount",
      headerName: "Amount",
      headerAlign: "center",
      align: "center",
      width: 140,

      renderCell: (params) => (
        <Typography fontWeight={700} color="success.main">
          ₹{params.value}
        </Typography>
      ),
    },

    {
      field: "created_at",
      headerName: "Created Date",
      headerAlign: "center",
      align: "center",
      flex: 0.6,
      minWidth: 100,

      renderCell: (params) =>
        new Date(params.row.created_at).toLocaleDateString(),
    },

    {
      field: "updated_at",
      headerName: "Updated Date",
      flex: 0.6,
      headerAlign: "center",
      align: "center",
      minWidth: 100,

      renderCell: (params) =>
        new Date(params.row.updated_at).toLocaleDateString(),
    },
  ];

  // =========================================
  // JSX
  // =========================================

  if (!loading && rows.length === 0) {
  return null;
}
return (
    <Box
      sx={{
        mt: 3,

        borderRadius: 3,

        overflow: "hidden",

        background: "transparent",
      }}
    >
      {/* HEADER */}

      <Box
        sx={{
          px: 3,
          py: 2,
          borderBottom: "1px solid #e5e7eb",
          color: "#3F6F7A",
        }}
      >
        <Typography variant="h6" fontWeight={700}>
          IPD Bed Charges
        </Typography>
      </Box>

      {/* TABLE */}

      <Box sx={{ headerAlign: "center", align: "center", width: "100%" }}>
        <DataGrid
          rows={rows}
          columns={columns}
          loading={loading}
          autoHeight
          pageSizeOptions={[5, 10, 20]}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 5,
              },
            },
          }}
          disableRowSelectionOnClick
          sx={{
            border: "none",

            backgroundColor: "transparent",

            "& .MuiDataGrid-main": {
              backgroundColor: "transparent",
            },

            "& .MuiDataGrid-row": {
              backgroundColor: "transparent",
            },

            "& .MuiDataGrid-cell": {
              backgroundColor: "transparent",
            },

            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: "#f1f5f9",
            },

            "& .MuiDataGrid-columnHeaderTitle": {
              fontWeight: 700,
            },
            "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
              {
                marginTop: "0px",
                marginBottom: "0px",
              },
            "& .MuiDataGrid-cell": {
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            },
          }}
        />
      </Box>
    </Box>
  );
}
