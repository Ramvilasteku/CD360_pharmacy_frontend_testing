import React, { useCallback, useEffect, useState } from "react";

import axios from "axios";

import { Box, Paper, Typography } from "@mui/material";

import { DataGrid } from "@mui/x-data-grid";

const API = process.env.REACT_APP_URL_IPD;

export default function IpdMiscChargesSection({ ipdId }) {
  const [rows, setRows] = useState([]);

  const [loading, setLoading] = useState(true);

  const fetchCharges = useCallback(async () => {
    try {
      setLoading(true);

      const res = await axios.get(`${API}/api/getall/misc-charges`, {
        params: {
          ipd_id: ipdId,
        },
        withCredentials: true,
      });

      setRows(res.data.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [ipdId]);

  useEffect(() => {
    fetchCharges();
  }, [fetchCharges]);

  const columns = [
    {
      field: "id",
      headerName: "ID",
      headerAlign: "center",
      align: "center",
      width: 90,
    },

    {
      field: "charge_date",
      headerName: "Charge Date",
      headerAlign: "center",
      align: "center",
      width: 160,
    },

    {
      field: "description",
      headerName: "Description",
      flex: 1,
      headerAlign: "center",
      align: "center",
      minwidth: 300,
       renderCell: (params) => (
        <div
          style={{
            maxHeight: "60px",
            overflowY: "auto",
            overflowX: "hidden",
            whiteSpace: "normal",
            wordBreak: "break-word",
            width: "100%",
            padding: "1px",
          }}
        >
          {params.value}
        </div>
      ),
    },

    {
      field: "charge_amount",
      headerName: "Amount",
      headerAlign: "center",
      align: "center",
      width: 150,

      renderCell: (params) => (
        <Typography fontWeight={700} color="success.main">
          ₹{params.value}
        </Typography>
      ),
    },
  ];

  
if (!loading && rows.length === 0) {
  return null;
}
return (
    <Box
      sx={{
        mt: 3,

        // border: "1px solid #e5e7eb",

        borderRadius: 3,

        overflow: "hidden",

        background: "transparent",
      }}
    >
      <Box
        sx={{
          px: 3,
          py: 2,
          borderBottom: "solid 0.1px #e0e0e0 ",
          color: "#3F6F7A",
        }}
      >
        <Typography variant="h6" fontWeight={700}>
          Misc Charges
        </Typography>
      </Box>

      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        pageSizeOptions={[5, 10]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        disableRowSelectionOnClick
        sx={{
          border: "none",

          backgroundColor: "transparent",

          "& .MuiDataGrid-main": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-row": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-cell": {
            backgroundColor: "transparent",
          },

          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#f1f5f9",
          },

          "& .MuiDataGrid-columnHeaderTitle": {
            fontWeight: 700,
          },
          "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
            {
              marginTop: "0px",
              marginBottom: "0px",
            },
          "& .MuiDataGrid-cell": {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          },
        }}
      />
    </Box>
  );
}
