// IpdDetailModal.jsx
// Main modal that opens when clicking on an IPD ID row.
// Shows patient details + all sub-sections (Bed Charges, Bed Allocation,
// Doctor Visits, Lab Tests, Procedures, Nursing Charges, Misc Charges).
//
// HOW TO USE:
//   1. Place this file and all other files from this set in your src/components/ipd/ folder.
//   2. Import and render <IpdDetailModal /> inside IpdAdmission.jsx (see bottom of this file for example).
//   3. Pass the selected admission object as `admission` prop and an `onClose` callback.
//
// DEPENDENCIES: axios, ./IpdBedChargesSection, ./IpdBedAllocationSection,
//   ./IpdDoctorVisitsSection, ./IpdLabTestsSection, ./IpdProceduresSection,
//   ./IpdNursingChargesSection, ./IpdMiscChargesSection, ./IpdDetailModal.css

import React, { useEffect, useState } from "react";
import axios from "axios";

import IpdBedChargesSection from "./IpdBedChargesSection";
import IpdBedAllocationSection from "./IpdBedAllocationSection";
import IpdDoctorVisitsSection from "./IpdDoctorVisitsSection";
import IpdLabTestsSection from "./IpdLabTestsSection";
import IpdProceduresSection from "./IpdProceduresSection";
import IpdNursingChargesSection from "./IpdNursingChargesSection";
import IpdMiscChargesSection from "./IpdMiscChargesSection";

import BedroomChildIcon from '@mui/icons-material/BedroomChild';

import "./IpdDetailModal.css";
import IpdBillsSection from "./IpdBillsSection";
import IpdPharmacyIssuesSection from "./IpdPharmacyIssuesSection";
import IpdPaymentsSection from "./IpdPaymentsSection";

export default function IpdDetailModal({ admission, onClose }) {
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch full IPD detail (clients, doctors info may already be on the admission object)
  // We just enrich it if needed; for now we use the passed admission directly.
  useEffect(() => {
    if (!admission) return;
    setDetail(admission);
    setLoading(false);
  }, [admission]);

  // Prevent body scroll while modal is open
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  if (!admission) return null;

  return (
    <div className="idm-overlay" onClick={onClose}>
      <div className="idm-panel" onClick={(e) => e.stopPropagation()}>
        {/* ── HEADER ── */}
        <div className="idm-header">
          <div className="idm-header-left">
            <span className="idm-badge"> IPD</span>
            <h2 className="idm-title">
              
              <BedroomChildIcon /> {admission.id} / {admission.client_name}
            </h2>
          </div>
          <button className="idm-close" onClick={onClose}>
            ✕
          </button>
        </div>

        {loading ? (
          <div className="idm-loader">Loading patient details…</div>
        ) : (
          <div className="idm-body">
            {/* ── PATIENT INFO CARD ── */}
            <div className="idm-info-grid">
              <InfoItem label="Client ID" value={detail.client_id} />
              <InfoItem label="Client Name" value={detail.client_name || "—"} />
              <InfoItem label="Branch" value={detail.branch_name || "—"} />
              <InfoItem label="Doctor ID" value={detail.doctor_id || "—"} />
              <InfoItem label="Doctor Name" value={detail.doctor_name || "—"} />
              <InfoItem label="Bed ID" value={detail.bed_id || "—"} />
              
              <InfoItem
                label="Admission Date"
                value={fmtDate(detail.admission_date)}
              />
              <InfoItem
                label="Discharge Date"
                value={fmtDate(detail.discharge_date)}
              />
              <InfoItem label="Allocated Bed ID" value={detail.bed_allocation_id || "—"} />
              
              <InfoItem
                label="Created Date"
                value={fmtDate(detail.created_at)}
              />
              <InfoItem
                label="Updated Date"
                value={fmtDate(detail.updated_at)}
              />
              <InfoItem
                label="Status"
                value={
                  <span className={`idm-status ${detail.status}`}>
                    {detail.status}
                  </span>
                }
              />
              <InfoItem
                label="Admission Reason"
                value={detail.admission_reason || "—"}
                wide
              />
              <InfoItem
                label="Discharge Summary"
                value={detail.discharge_summary || "—"}
                wide
              />
            </div>

            {/* ── SECTIONS ── */}
            <IpdBedChargesSection ipdId={admission.id} />
            <IpdBedAllocationSection ipdId={admission.id} />
            <IpdDoctorVisitsSection ipdId={admission.id} />
            <IpdLabTestsSection ipdId={admission.id} />
            <IpdProceduresSection ipdId={admission.id} />
            <IpdNursingChargesSection ipdId={admission.id} />
            <IpdMiscChargesSection ipdId={admission.id} />
            <IpdPharmacyIssuesSection ipdId={admission.id} />
            <IpdBillsSection ipdId={admission.id} />
            <IpdPaymentsSection ipdId={admission.id} />
          </div>
        )}
      </div>
    </div>
  );
}

// ── tiny helper components ──────────────────────────────────────────────────
function InfoItem({ label, value, wide }) {
  return (
    <div className={`idm-info-item ${wide ? "wide" : ""}`}>
      <span className="idm-info-label">{label}</span>
      <span className="idm-info-value">{value ?? "—"}</span>
    </div>
  );
}

function fmtDate(val) {
  if (!val) return "—";
  return new Date(val).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   HOW TO WIRE THIS INTO IpdAdmission.jsx
   ─────────────────────────────────────────────────────────────────────────────
   1. Add state:
        const [detailAdmission, setDetailAdmission] = useState(null);

   2. Make the IPD ID cell clickable in AdmissionRow:
        <td
          className="ipd-id-link"
          onClick={() => setDetailAdmission(admission)}
          style={{ cursor: "pointer", color: "#2563eb", textDecoration: "underline" }}
        >
          {admission.id}
        </td>

   3. Render the modal at the bottom of IpdAdmission return (after existing modal):
        {detailAdmission && (
          <IpdDetailModal
            admission={detailAdmission}
            onClose={() => setDetailAdmission(null)}
          />
        )}
   ───────────────────────────────────────────────────────────────────────────── */
