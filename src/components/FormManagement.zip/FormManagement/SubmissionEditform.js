/*
====================================================================
SubmissionEditForm.jsx

Replaces / extends SubmissionView. Instead of a flat read-only
key -> value list, this opens the submission as an editable form,
pre-filled with the patient's already-submitted answers, grouped
into the same sections as the original form_schema when possible.

Assumed field shape (adjust to match your actual FormBuilder):
  {
    id: "full_name",
    label: "Full Name",
    type: "text" | "textarea" | "checkbox" | "checkbox-group"
          | "radio" | "select" | "date",
    options: ["Yes", "No"]   // for checkbox-group / radio / select
  }

Assumed schema shape (falls back gracefully if different):
  [
    { title: "Patient Registration", fields: [ ... ] },
    { title: "Medical History", fields: [ ... ] },
    ...
  ]

If your actual schema/field shape differs, send me a real sample
and I'll adjust renderField() / normalizeSchema() to match exactly
instead of relying on this fallback.
====================================================================
*/

import React, { useEffect, useState, useMemo } from "react";

import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    Box,
    Divider,
    CircularProgress,
    TextField,
    FormControlLabel,
    Checkbox,
    RadioGroup,
    Radio,
    MenuItem,
    Alert
} from "@mui/material";

import {
    getSubmissionById,
    updateSubmission
} from "./formManagementApi";


// Normalizes whatever shape form_schema is into
// [{ title, fields: [{ id, label, type, options }] }]
function normalizeSchema(formSchema, formData) {
    if (Array.isArray(formSchema) && formSchema.length > 0 && formSchema[0].fields) {
        return formSchema;
    }

    if (Array.isArray(formSchema) && formSchema.length > 0 && formSchema[0].id) {
        // flat field array, no sections
        return [{ title: "Form Details", fields: formSchema }];
    }

    // No usable schema — fall back to plain fields built from the
    // saved data itself, all as text inputs.
    return [
        {
            title: "Submitted Details",
            fields: Object.keys(formData || {}).map((key) => ({
                id: key,
                label: key.replace(/_/g, " "),
                type: "text"
            }))
        }
    ];
}


const SubmissionEditForm = ({ id, open, close, onSaved }) => {

    const [submission, setSubmission] = useState(null);
    const [values, setValues] = useState({});
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState(null);

    const fetchSubmission = async () => {
        try {
            setLoading(true);
            setError(null);

            const response = await getSubmissionById(id);

            setSubmission(response);
            setValues(response.form_data || {});

        } catch (err) {
            console.log("Submission Edit Fetch Error:", err);
            setError("Could not load this submission.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (id && open) {
            fetchSubmission();
        }
        if (!open) {
            // reset on close so stale data doesn't flash next open
            setSubmission(null);
            setValues({});
            setError(null);
        }
    }, [id, open]);

    const sections = useMemo(
        () => normalizeSchema(submission?.form_schema, submission?.form_data),
        [submission]
    );

    const setFieldValue = (fieldId, value) => {
        setValues((prev) => ({ ...prev, [fieldId]: value }));
    };

    const toggleCheckboxGroupValue = (fieldId, option, checked) => {
        setValues((prev) => {
            const current = Array.isArray(prev[fieldId]) ? prev[fieldId] : [];
            const next = checked
                ? [...current, option]
                : current.filter((o) => o !== option);
            return { ...prev, [fieldId]: next };
        });
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            setError(null);

            await updateSubmission(id, { form_data: values });

            if (onSaved) onSaved();
            close();

        } catch (err) {
            console.log("Submission Save Error:", err);
            setError("Could not save changes. Please try again.");
        } finally {
            setSaving(false);
        }
    };

    const renderField = (field) => {
        const value = values[field.id];

        switch (field.type) {

            case "checkbox":
                return (
                    <FormControlLabel
                        key={field.id}
                        control={
                            <Checkbox
                                checked={!!value}
                                onChange={(e) =>
                                    setFieldValue(field.id, e.target.checked)
                                }
                            />
                        }
                        label={field.label}
                    />
                );

            case "checkbox-group":
                return (
                    <Box key={field.id} mb={2}>
                        <Typography fontWeight={600} mb={0.5}>
                            {field.label}
                        </Typography>
                        <Box display="flex" flexWrap="wrap" gap={1}>
                            {(field.options || []).map((opt) => (
                                <FormControlLabel
                                    key={opt}
                                    control={
                                        <Checkbox
                                            checked={
                                                Array.isArray(value) &&
                                                value.includes(opt)
                                            }
                                            onChange={(e) =>
                                                toggleCheckboxGroupValue(
                                                    field.id,
                                                    opt,
                                                    e.target.checked
                                                )
                                            }
                                        />
                                    }
                                    label={opt}
                                />
                            ))}
                        </Box>
                    </Box>
                );

            case "radio":
                return (
                    <Box key={field.id} mb={2}>
                        <Typography fontWeight={600} mb={0.5}>
                            {field.label}
                        </Typography>
                        <RadioGroup
                            row
                            value={value || ""}
                            onChange={(e) =>
                                setFieldValue(field.id, e.target.value)
                            }
                        >
                            {(field.options || []).map((opt) => (
                                <FormControlLabel
                                    key={opt}
                                    value={opt}
                                    control={<Radio />}
                                    label={opt}
                                />
                            ))}
                        </RadioGroup>
                    </Box>
                );

            case "select":
                return (
                    <TextField
                        key={field.id}
                        select
                        fullWidth
                        label={field.label}
                        value={value || ""}
                        onChange={(e) =>
                            setFieldValue(field.id, e.target.value)
                        }
                        sx={{ mb: 2 }}
                    >
                        {(field.options || []).map((opt) => (
                            <MenuItem key={opt} value={opt}>
                                {opt}
                            </MenuItem>
                        ))}
                    </TextField>
                );

            case "date":
                return (
                    <TextField
                        key={field.id}
                        type="date"
                        fullWidth
                        label={field.label}
                        InputLabelProps={{ shrink: true }}
                        value={value || ""}
                        onChange={(e) =>
                            setFieldValue(field.id, e.target.value)
                        }
                        sx={{ mb: 2 }}
                    />
                );

            case "textarea":
                return (
                    <TextField
                        key={field.id}
                        fullWidth
                        multiline
                        minRows={3}
                        label={field.label}
                        value={value || ""}
                        onChange={(e) =>
                            setFieldValue(field.id, e.target.value)
                        }
                        sx={{ mb: 2 }}
                    />
                );

            case "text":
            default:
                return (
                    <TextField
                        key={field.id}
                        fullWidth
                        label={field.label}
                        value={value ?? ""}
                        onChange={(e) =>
                            setFieldValue(field.id, e.target.value)
                        }
                        sx={{ mb: 2 }}
                    />
                );
        }
    };

    return (
        <Dialog open={open} onClose={close} fullWidth maxWidth="md">
            <DialogTitle>
                Edit Submission
                {submission?.client_name ? ` — ${submission.client_name}` : ""}
            </DialogTitle>

            <DialogContent dividers>
                {loading ? (
                    <Box display="flex" justifyContent="center" p={4}>
                        <CircularProgress />
                    </Box>
                ) : submission ? (
                    <>
                        {error && (
                            <Alert severity="error" sx={{ mb: 2 }}>
                                {error}
                            </Alert>
                        )}

                        <Box mb={2}>
                            <Typography>
                                <b>Email:</b> {submission.email || "N/A"}
                            </Typography>
                            <Typography>
                                <b>Phone:</b> {submission.mobile || submission.phone || "N/A"}
                            </Typography>
                            <Typography>
                                <b>Form:</b> {submission.form_name} ({submission.form_type})
                            </Typography>
                        </Box>

                        <Divider sx={{ my: 2 }} />

                        {sections.map((section, idx) => (
                            <Box key={idx} mb={3}>
                                <Typography variant="h6" mb={2}>
                                    {section.title}
                                </Typography>
                                {(section.fields || []).map(renderField)}
                            </Box>
                        ))}
                    </>
                ) : (
                    error && <Alert severity="error">{error}</Alert>
                )}
            </DialogContent>

            <DialogActions>
                <Button onClick={close} disabled={saving}>
                    Cancel
                </Button>
                <Button
                    onClick={handleSave}
                    variant="contained"
                    disabled={loading || saving || !submission}
                >
                    {saving ? "Saving..." : "Save Changes"}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default SubmissionEditForm;