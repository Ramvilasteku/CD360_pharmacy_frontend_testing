import React, { useState } from "react";
import axios from "axios";
import { Box, Button, ButtonGroup, Typography } from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import TemplateSelector from "./TemplateSelector";
import FormBuilder from "./FormBuilder";
import FormPreview from "./FormPreview";
import FormsList from "./Formslist";

const API = process.env.REACT_APP_FORM_MODULE_API_URL;

/*
  WHAT CHANGED FROM THE OLD VERSION:

  The old component only ever held ONE `schema` in state. Uploading a
  PDF always overwrote it, there was no list of previously-created
  forms, and no way to go back and edit one specific form later —
  every upload effectively behaved like the only form that existed.

  This version has three views:

    "list"      -> FormsList: every form the admin has created, each
                   with its own Preview / Edit buttons, plus an
                   "Upload New PDF" button that starts a brand new
                   form (never touches an existing one).

    "upload"    -> TemplateSelector: fetches every known form
                   template from the backend, lets the admin pick a
                   form type, shows it read-only in FormPreview, and
                   offers Preview / Edit / Delete on that template.
                   Edit hands the schema off into the builder below.

    "workspace" -> the currently open form (new or existing), with a
                   top [Edit] / [Preview] toggle. Both tabs share the
                   same `schema` state, so switching to Preview always
                   reflects whatever was just edited.
*/

const FormManagement = () => {
  const [view, setView] = useState("list"); // "list" | "upload" | "workspace"
  const [tab, setTab] = useState("edit");   // "edit" | "preview" (workspace only)

  const [schema, setSchema] = useState(null);
  const [formMeta, setFormMeta] = useState({
    mode: "create",       // "create" | "edit"
    formId: null,
    templateId: null,
    formName: "",
    formType: "registration",
  });

  const [loadError, setLoadError] = useState("");

  const backToList = () => {
    setView("list");
    setSchema(null);
    setLoadError("");
  };

  const handleCreateNew = () => {
    setLoadError("");
    setView("upload");
  };

  // Called from TemplateSelector when the admin chooses to edit a form type
  const handleUseTemplate = ({ schema, templateId, suggestedName }) => {
  setSchema(schema);
  setFormMeta({
    mode: "create",
    formId: null,
    templateId,
    formName: suggestedName || schema.title || "",
    formType: "registration",
  });
  setTab("edit");
  setView("workspace");
};

  const loadExistingForm = async (formId) => {
    setLoadError("");
    try {
      const res = await axios.get(`${API}/form-management/form/${formId}`, {
        withCredentials: true,
      });
      setSchema(res.data.form_schema);
      setFormMeta({
        mode: "edit",
        formId: res.data.id,
        templateId: null,
        formName: res.data.form_name,
        formType: res.data.form_type,
      });
      return true;
    } catch (error) {
      console.log("Load Form Error:", error);
      setLoadError("Failed to load that form.");
      return false;
    }
  };

  const handlePreview = async (formId) => {
    const ok = await loadExistingForm(formId);
    if (ok) {
      setTab("preview");
      setView("workspace");
    }
  };

  const handleEdit = async (formId) => {
    const ok = await loadExistingForm(formId);
    if (ok) {
      setTab("edit");
      setView("workspace");
    }
  };

  const handleSaved = () => {
    // Whether we just created a new form or updated an existing one,
    // return to the list so the admin sees the up-to-date set of forms.
    backToList();
  };

  return (
    <Box className="form-management-container">
      <h1>Form Management</h1>

      {view === "list" && (
        <FormsList
          onCreateNew={handleCreateNew}
          onPreview={handlePreview}
          onEdit={handleEdit}
        />
      )}

      {view === "upload" && (
        <Box sx={{ maxWidth: 720, mx: "auto", px: { xs: 2, sm: 0 } }}>
          <Button
            onClick={backToList}
            startIcon={<ArrowBackIcon fontSize="small" />}
            sx={{ mb: 2, textTransform: "none", color: "#3f6f7a", fontWeight: 600 }}
          >
            Back to Forms
          </Button>
          <TemplateSelector onUseTemplate={handleUseTemplate} />
        </Box>
      )}

      {view === "workspace" && schema && (
        <Box sx={{ maxWidth: 720, mx: "auto", px: { xs: 2, sm: 0 } }}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 2,
              flexWrap: "wrap",
              gap: 1,
            }}
          >
            <Button
              onClick={backToList}
              startIcon={<ArrowBackIcon fontSize="small" />}
              sx={{ textTransform: "none", color: "#3f6f7a", fontWeight: 600 }}
            >
              Back to Forms
            </Button>

            {/* Top Preview / Edit toggle for the form currently open */}
            <ButtonGroup>
              <Button
                variant={tab === "edit" ? "contained" : "outlined"}
                onClick={() => setTab("edit")}
                sx={{
                  textTransform: "none",
                  fontWeight: 600,
                  bgcolor: tab === "edit" ? "#3f6f7a" : "transparent",
                  borderColor: "#3f6f7a",
                  color: tab === "edit" ? "#fff" : "#3f6f7a",
                  "&:hover": {
                    bgcolor: tab === "edit" ? "#2c4e56" : "rgba(63,111,122,0.06)",
                    borderColor: "#3f6f7a",
                  },
                }}
              >
                Edit
              </Button>
              <Button
                variant={tab === "preview" ? "contained" : "outlined"}
                onClick={() => setTab("preview")}
                sx={{
                  textTransform: "none",
                  fontWeight: 600,
                  bgcolor: tab === "preview" ? "#3f6f7a" : "transparent",
                  borderColor: "#3f6f7a",
                  color: tab === "preview" ? "#fff" : "#3f6f7a",
                  "&:hover": {
                    bgcolor: tab === "preview" ? "#2c4e56" : "rgba(63,111,122,0.06)",
                    borderColor: "#3f6f7a",
                  },
                }}
              >
                Preview
              </Button>
            </ButtonGroup>
          </Box>

          {loadError && (
            <Typography sx={{ color: "#c0392b", mb: 2 }}>{loadError}</Typography>
          )}

          {tab === "edit" && (
            <FormBuilder
              schema={schema}
              setSchema={setSchema}
              mode={formMeta.mode}
              formId={formMeta.formId}
              templateId={formMeta.templateId}
              initialFormName={formMeta.formName}
              initialFormType={formMeta.formType}
              onSaved={handleSaved}
            />
          )}

          {tab === "preview" && <FormPreview schema={schema} />}
        </Box>
      )}
    </Box>
  );
};

export default FormManagement;