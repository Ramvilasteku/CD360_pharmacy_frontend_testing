import React,{useEffect,useState} from "react";


import {

Box,
Typography,
Paper,
Table,
TableBody,
TableCell,
TableContainer,
TableHead,
TableRow,
IconButton,
Chip

} from "@mui/material";


import VisibilityIcon from "@mui/icons-material/Visibility";

import DeleteIcon from "@mui/icons-material/Delete";

import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";



import {

getSubmissions,
deleteSubmission,
downloadSubmissionPDF

}
from "./formManagementApi";



import SubmissionView from "./SubmissionView";





const AdminSubmissions=()=>{


const [submissions,setSubmissions]=useState([]);

const [viewId,setViewId]=useState(null);





const loadSubmissions=async()=>{


    try{

        const data =
        await getSubmissions();


        setSubmissions(data);


    }
    catch(error){

        console.log(
            "Submission Fetch Error",
            error
        );

    }


};




useEffect(()=>{


loadSubmissions();


},[]);







const removeSubmission=async(id)=>{


const confirmDelete =
window.confirm(
"Are you sure you want to delete?"
);



if(!confirmDelete)
return;



await deleteSubmission(id);


loadSubmissions();


};







return(

<Box
sx={{
padding:"25px"
}}
>


<Typography

variant="h5"

fontWeight="600"

mb={3}

>

Patient Submitted Forms

</Typography>





<TableContainer
component={Paper}
>


<Table>


<TableHead>


<TableRow>


<TableCell>
S.No
</TableCell>


<TableCell>
Patient Name
</TableCell>


<TableCell>
Form Name
</TableCell>


<TableCell>
Form Type
</TableCell>


<TableCell>
Date
</TableCell>


<TableCell>
Actions
</TableCell>


</TableRow>


</TableHead>





<TableBody>



{

submissions.map((item,index)=>(


<TableRow
key={item.id}
>


<TableCell>

{index+1}

</TableCell>





<TableCell>


<Typography>

{item.client_name || "N/A"}

</Typography>


<Typography
fontSize="12px"
color="gray"
>

{item.email}

</Typography>


</TableCell>






<TableCell>

{item.form_name}

</TableCell>





<TableCell>


<Chip

label={item.form_type}

size="small"

/>


</TableCell>





<TableCell>


{
new Date(
item.created_at
)
.toLocaleString()
}


</TableCell>





<TableCell>



<IconButton

color="primary"

onClick={()=>setViewId(item.id)}

>

<VisibilityIcon/>

</IconButton>






<IconButton

color="success"

onClick={()=>
downloadSubmissionPDF(item.id)
}

>


<PictureAsPdfIcon/>


</IconButton>






<IconButton

color="error"

onClick={()=>
removeSubmission(item.id)
}

>


<DeleteIcon/>


</IconButton>





</TableCell>




</TableRow>


))


}





</TableBody>


</Table>


</TableContainer>








{
viewId &&


<SubmissionView

id={viewId}

open={true}

close={()=>setViewId(null)}

/>


}



</Box>


);


};



export default AdminSubmissions;