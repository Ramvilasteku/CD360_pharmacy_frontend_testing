import axios from "axios";


const API_URL =
process.env.REACT_APP_FORM_MODULE_API_URL;



// GET ALL SUBMISSIONS

export const getSubmissions = async()=>{


    const response = await axios.get(

        `${API_URL}/form-management/submissions`,

        {
            withCredentials:true
        }

    );


    return response.data;

};


// UPDATE SUBMISSION

export const updateSubmission = async (id, payload) => {

    const response = await axios.put(

        `${API_URL}/form-management/submissions/${id}`,

        payload,

        {
            withCredentials:true
        }

    );

    return response.data;

};
 



// GET SINGLE SUBMISSION

export const getSubmissionById = async(id)=>{


    const response = await axios.get(

        `${API_URL}/form-management/submissions/${id}`,

        {
            withCredentials:true
        }

    );


    return response.data;


};





// DELETE SUBMISSION


export const deleteSubmission = async(id)=>{


    const response = await axios.delete(

        `${API_URL}/form-management/submissions/${id}`,

        {
            withCredentials:true
        }

    );


    return response.data;

};





// DOWNLOAD PDF


export const downloadSubmissionPDF = async(id)=>{


    const response = await axios.get(

        `${API_URL}/form-management/submissions/${id}/pdf`,

        {
            withCredentials:true,
            responseType:"blob"
        }

    );



    const fileURL =
    window.URL.createObjectURL(
        new Blob([response.data])
    );


    const link =
    document.createElement("a");


    link.href=fileURL;


    link.download=
    `submission_${id}.pdf`;


    document.body.appendChild(link);


    link.click();


    link.remove();


};