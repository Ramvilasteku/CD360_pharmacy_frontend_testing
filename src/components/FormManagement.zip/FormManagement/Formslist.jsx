import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Box,
  Typography,
  Button,
  Chip,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";
import DescriptionIcon from "@mui/icons-material/Description";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";

const API = process.env.REACT_APP_FORM_MODULE_API_URL;

/*
  Replaces the old TemplateList.jsx, which:
    1) called GET /form-management/templates but read `form_name`/
       `form_type` off the response — the API actually returns
       `template_name`/`template_type`, so every row rendered blank.
    2) was never even imported into FormManagement.jsx, so none of
       this was reachable in the app.

  This component instead calls GET /form-management/admin/forms
  (the endpoint that already existed in formManagement.controller.js
  but had no frontend consumer) and gives each form its own
  Preview / Edit buttons, plus a top "Upload New PDF" button that
  starts a brand new form without touching any existing one.
*/

const FormsList = ({ onCreateNew, onPreview, onEdit }) => {
  const [forms, setForms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const confirmDelete = (form, e) => {
    e.stopPropagation();
    setDeleteTarget(form);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;

    try {
      setDeleting(true);

      await axios.delete(
        `${API}/form-management/delete/${deleteTarget.id}`,
        { withCredentials: true }
      );

      setForms((prev) => prev.filter((f) => f.id !== deleteTarget.id));
    } catch (error) {
      console.log("Form Delete Error", error);
      setErrorMsg("Failed to delete that form.");
    } finally {
      setDeleting(false);
      setDeleteTarget(null);
    }
  };

  const getForms = async () => {
    try {
      setLoading(true);
      setErrorMsg("");

      const response = await axios.get(
        `${process.env.REACT_APP_FORM_MODULE_API_URL}/form-management/admin/forms`,
        { withCredentials: true }
      );

      setForms(response.data);
    } catch (error) {
      console.log("Forms Fetch Error", error);
      setErrorMsg("Failed to load your forms.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getForms();
  }, []);

  return (
    <Box sx={{ width: "100%", maxWidth: 720, mx: "auto", px: { xs: 2, sm: 0 } }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: 1.5,
          mb: 3,
        }}
      >
        <Typography variant="h5" sx={{ fontWeight: 700, color: "#274850" }}>
          Forms
        </Typography>

        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={onCreateNew}
          sx={{
            textTransform: "none",
            fontWeight: 700,
            borderRadius: "999px",
            bgcolor: "#3f6f7a",
            boxShadow: "none",
            "&:hover": { bgcolor: "#2c4e56", boxShadow: "none" },
          }}
        >
          New Form
        </Button>
      </Box>

      {loading && (
        <Typography sx={{ color: "#7c8a8d" }}>Loading forms…</Typography>
      )}

      {!loading && errorMsg && (
        <Typography sx={{ color: "#c0392b" }}>{errorMsg}</Typography>
      )}

      {!loading && !errorMsg && forms.length === 0 && (
        <Box
          sx={{
            backgroundColor: "#fff",
            borderRadius: "18px",
            boxShadow: "0 2px 12px rgba(63,111,122,0.06)",
            p: 4,
            textAlign: "center",
          }}
        >
          <DescriptionIcon sx={{ fontSize: 32, color: "#c7d2d4", mb: 1 }} />
          <Typography sx={{ color: "#7c8a8d" }}>
            No forms yet. Upload a PDF to create your first form.
          </Typography>
        </Box>
      )}

      {forms.map((form) => (
        <Box
          key={form.id}
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            backgroundColor: "#fff",
            borderRadius: "14px",
            boxShadow: "0 2px 12px rgba(63,111,122,0.06)",
            p: 2,
            mb: 1.5,
            gap: 1,
          }}
        >
          <Box sx={{ minWidth: 0 }}>
            <Typography noWrap sx={{ fontWeight: 700, color: "#274850" }}>
              {form.form_name}
            </Typography>
            <Chip
              label={form.form_type}
              size="small"
              sx={{
                mt: 0.5,
                backgroundColor: "rgba(63,111,122,0.1)",
                color: "#3f6f7a",
                fontWeight: 600,
                fontSize: 11,
              }}
            />
          </Box>

          <Box sx={{ display: "flex", gap: 0.5, flexShrink: 0 }}>
            <Tooltip title="Preview">
              <IconButton onClick={() => onPreview(form.id)} sx={{ color: "#3f6f7a" }}>
                <VisibilityIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Tooltip title="Edit fields">
              <IconButton onClick={() => onEdit(form.id)} sx={{ color: "#3f6f7a" }}>
                <EditIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Tooltip title="Delete form">
              <IconButton onClick={(e) => confirmDelete(form, e)} sx={{ color: "#c0392b" }}>
                <DeleteOutlineIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
      ))}

      <Dialog open={Boolean(deleteTarget)} onClose={() => !deleting && setDeleteTarget(null)}>
        <DialogTitle sx={{ fontWeight: 700, color: "#274850" }}>
          Delete this form?
        </DialogTitle>
        <DialogContent>
          <Typography sx={{ color: "#7c8a8d" }}>
            "{deleteTarget?.form_name}" and its field configuration will be
            permanently removed. This does not delete past submissions.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={() => setDeleteTarget(null)}
            disabled={deleting}
            sx={{ textTransform: "none", color: "#7c8a8d", fontWeight: 600 }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleDelete}
            disabled={deleting}
            variant="contained"
            sx={{
              textTransform: "none",
              fontWeight: 700,
              borderRadius: "999px",
              bgcolor: "#c0392b",
              boxShadow: "none",
              "&:hover": { bgcolor: "#a5301f", boxShadow: "none" },
            }}
          >
            {deleting ? "Deleting…" : "Delete"}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default FormsList;