import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { styled, useTheme } from "@mui/material/styles";
import { useDispatch } from "react-redux";

/* MUI imports */
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Collapse from "@mui/material/Collapse";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import { Avatar, Menu, MenuItem, Stack } from "@mui/material";
import PersonIcon from "@mui/icons-material/Person";
import LogoutIcon from "@mui/icons-material/Logout";

/* ═══════════════════════════════════════════════════════════════════
   ⭐ MODULE-DRIVEN IMPORTS
   ═══════════════════════════════════════════════════════════════════ */
import { useMenuAccess } from "../Redux/store/hooks/useMenuAccess";
import { getIcon } from "../Redux/config/iconRegistry";

/* Content components (your existing ones) */
import Dashboard from "./Dashboard";
import Employees from "./Employees";
import AdminProfile from "./AdminProfile";
import Appointments from "./Appointments";
import StaffAttendance from "./StaffAttendance";
import LeaveRequest from "./LeaveRequest";
import AdminReviews from "./AdminReviews";
import AdminBills from "./AdminBills";
import PaymentsTable from "./Payments";
import AddMedicine from "./AddMedicine";
import AddMedicalTests from "./AddMedicalTests";
import ConsultationTypes from "./Consultationtypes";
import SendNotification from "./UpdatedNotifications";
import RoleManager from "./RoleModule/RoleManager";
import ClientsCards from "./ClientsCards";

/* IPD components */
import IPDAdmissions from "./IPD/IPDAdmissions";
import WardType from "./IPD/WardType";
import Rooms from "./IPD/Rooms";
import Beds from "./IPD/Beds";
import IPDAnalytics from "./IPD/IPDAnalytics/IPDAnalytics";

/* Pharmacy components */
import PharmacyDashboard from "../Redux/dashboard/PharmacyDashboard";

/* Notification listener */
import NotificationListener from "../NotificationListener";
import NotificationBell from "../NotificationBell";

const drawerWidth = 250;

/* ═══════════════════════════════════════════════════════════════════
   PLACEHOLDER FOR "COMING SOON" PAGES
   ═══════════════════════════════════════════════════════════════════ */
function ComingSoon({ title }) {
  return (
    <Box sx={{ p: 4, textAlign: "center", minHeight: "60vh" }}>
      <Typography variant="h4" sx={{ color: "#3f6f7a", fontWeight: 600, mb: 2 }}>
        {title}
      </Typography>
      <Typography color="text.secondary">Coming soon</Typography>
    </Box>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   ACCESS DENIED (When user tries to access content they don't have)
   ═══════════════════════════════════════════════════════════════════ */
function AccessDenied() {
  return (
    <Box sx={{ p: 4, textAlign: "center", minHeight: "60vh" }}>
      <Typography variant="h5" sx={{ color: "#a32d2d", fontWeight: 600, mb: 2 }}>
        Access Denied
      </Typography>
      <Typography color="text.secondary">
        You don't have permission to view this section.
      </Typography>
    </Box>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   CONTENT REGISTRY - Maps contentKey to component
   ═══════════════════════════════════════════════════════════════════ */
const CONTENT_MAP = {
  Home: <Dashboard />,
  Employees: <Employees />,
  Profile: <AdminProfile />,
  Appointments: <Appointments />,
  Attendance: <StaffAttendance />,
  "Leave Requests": <LeaveRequest />,
  Reviews: <AdminReviews />,
  Bills: <AdminBills />,
  Payments: <PaymentsTable />,
  "Add Medicine": <AddMedicine />,
  "Add Medical Tests": <AddMedicalTests />,
  "Add Consultation Types": <ConsultationTypes />,
  Notifications: <SendNotification />,
  "Role Management": <RoleManager />,

  /* IPD */
  "IPD Home": <IPDAnalytics />,
  "IPD Admissions": <IPDAdmissions />,
  "Ward Type": <WardType />,
  Rooms: <Rooms />,
  Beds: <Beds />,

  /* Pharmacy */
  "Pharmacy Dashboard": <PharmacyDashboard />,
  "Medicines List": <ComingSoon title="Medicines List" />,
  Categories: <ComingSoon title="Categories" />,
  Batches: <ComingSoon title="Batches" />,
  "Stock View": <ComingSoon title="Stock View" />,
  "Low Stock": <ComingSoon title="Low Stock" />,
  "Expiry Alerts": <ComingSoon title="Expiry Alerts" />,
  "Stock Adjustments": <ComingSoon title="Stock Adjustments" />,
  "Stock Ledger": <ComingSoon title="Stock Ledger" />,
  Suppliers: <ComingSoon title="Suppliers" />,
  "Purchase Orders": <ComingSoon title="Purchase Orders" />,
  "GRN (Goods Receipt)": <ComingSoon title="Goods Receipt Note" />,
  "Purchase Returns": <ComingSoon title="Purchase Returns" />,
  Customers: <ComingSoon title="Customers" />,
  "POS / New Sale": <ComingSoon title="Point of Sale" />,
  "All Sales": <ComingSoon title="All Sales" />,
  "Sales Returns": <ComingSoon title="Sales Returns" />,
  "Pharmacy Payments": <ComingSoon title="Pharmacy Payments" />,
};

/* ═══════════════════════════════════════════════════════════════════
   MAIN COMPONENT
   ═══════════════════════════════════════════════════════════════════ */
export default function AdminDashboard() {
  const [content, setContent] = useState("Home");
  const [openDropdowns, setOpenDropdowns] = useState({});   // Track expanded dropdowns
  const [anchorEl, setAnchorEl] = useState(null);
  const profileopen = Boolean(anchorEl);

  const location = useLocation();
  const navigate = useNavigate();

  /* ⭐ THE MAGIC: filtered menu based on user's modules */
  const { visibleMenu, canAccessContent, role } = useMenuAccess();

  useEffect(() => {
    if (location.state?.content) {
      setContent(location.state.content);
    }
  }, [location.state]);

  const toggleDropdown = (key) => {
    setOpenDropdowns((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleClick = (event) => setAnchorEl(event.currentTarget);
  const handleClose = () => setAnchorEl(null);

  const handleLogout = async () => {
    try {
      await fetch(process.env.REACT_APP_LOGOUT, {
        method: "POST",
        credentials: "include",
      });
      localStorage.clear();
      navigate("/");
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  const companyName = localStorage.getItem("companyName");
  const companyLogo = localStorage.getItem("companyLogo");
  const ProfileName = localStorage.getItem("adminName") || localStorage.getItem("userName");

  const today = new Date().toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

  /* ═══════════════════════════════════════════════════════════════════
     RENDER: Single menu item
     ═══════════════════════════════════════════════════════════════════ */
  const renderItem = (item, depth = 0) => {
    const IconComponent = getIcon(item.iconName);
    const isSelected = content === item.contentKey;
    const paddingLeft = 2.5 + depth * 2;

    return (
      <ListItem key={item.key} disablePadding>
        <ListItemButton
          onClick={() => setContent(item.contentKey)}
          sx={{
            pl: paddingLeft,
            py: depth > 0 ? 0.3 : 0.5,
            backgroundColor: isSelected ? "#5f9aa6" : "transparent",
            color: "#fff",
            "&:hover": {
              backgroundColor: isSelected ? "#5f9aa6" : "rgba(255,255,255,0.05)",
            },
          }}
        >
          <ListItemIcon sx={{ color: "#fff", minWidth: depth > 0 ? 32 : 36 }}>
            <IconComponent fontSize={depth > 0 ? "small" : "medium"} />
          </ListItemIcon>
          <ListItemText
            primary={item.label}
            primaryTypographyProps={{ fontSize: depth > 0 ? "0.85rem" : "0.95rem" }}
          />
        </ListItemButton>
      </ListItem>
    );
  };

  /* ═══════════════════════════════════════════════════════════════════
     RENDER: Section (sub-group inside dropdown)
     ═══════════════════════════════════════════════════════════════════ */
  const renderSection = (section, depth = 0) => {
    const IconComponent = getIcon(section.iconName);
    const isOpen = openDropdowns[section.key];

    return (
      <React.Fragment key={section.key}>
        <ListItem disablePadding>
          <ListItemButton
            onClick={() => toggleDropdown(section.key)}
            sx={{
              pl: 2.5 + depth * 2,
              py: 0.5,
              color: "#fff",
              "&:hover": { backgroundColor: "rgba(255,255,255,0.05)" },
            }}
          >
            <ListItemIcon sx={{ color: "#fff", minWidth: 32 }}>
              <IconComponent fontSize="small" />
            </ListItemIcon>
            <ListItemText
              primary={section.label}
              primaryTypographyProps={{ fontSize: "0.9rem" }}
            />
            {isOpen ? <ExpandLess fontSize="small" /> : <ExpandMore fontSize="small" />}
          </ListItemButton>
        </ListItem>

        <Collapse in={isOpen} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            {section.children.map((child) => renderItem(child, depth + 2))}
          </List>
        </Collapse>
      </React.Fragment>
    );
  };

  /* ═══════════════════════════════════════════════════════════════════
     RENDER: Dropdown (top-level with children)
     ═══════════════════════════════════════════════════════════════════ */
  const renderDropdown = (dropdown) => {
    const IconComponent = getIcon(dropdown.iconName);
    const isOpen = openDropdowns[dropdown.key];

    return (
      <React.Fragment key={dropdown.key}>
        <ListItem disablePadding>
          <ListItemButton
            onClick={() => toggleDropdown(dropdown.key)}
            sx={{
              px: 2.5,
              color: "#fff",
              backgroundColor: isOpen ? "rgba(255,255,255,0.05)" : "transparent",
              "&:hover": { backgroundColor: "rgba(255,255,255,0.05)" },
            }}
          >
            <ListItemIcon sx={{ color: "#fff", minWidth: 36 }}>
              <IconComponent />
            </ListItemIcon>
            <ListItemText primary={dropdown.label} />
            {isOpen ? <ExpandLess /> : <ExpandMore />}
          </ListItemButton>
        </ListItem>

        <Collapse in={isOpen} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            {dropdown.children.map((child) => {
              if (child.type === "section") return renderSection(child, 1);
              return renderItem(child, 1);
            })}
          </List>
        </Collapse>
      </React.Fragment>
    );
  };

  /* ═══════════════════════════════════════════════════════════════════
     RENDER: Route menu item to correct renderer
     ═══════════════════════════════════════════════════════════════════ */
  const renderMenuItem = (item) => {
    if (item.type === "item") return renderItem(item);
    if (item.type === "dropdown") return renderDropdown(item);
    if (item.type === "section") return renderSection(item);
    return null;
  };

  /* ═══════════════════════════════════════════════════════════════════
     RENDER: Content area with access check
     ═══════════════════════════════════════════════════════════════════ */
  const renderContent = () => {
    // Verify user can access this content (security check)
    if (!canAccessContent(content)) {
      return <AccessDenied />;
    }

    return CONTENT_MAP[content] || <ComingSoon title={content} />;
  };

  return (
    <>
      <NotificationListener />
      <Box sx={{ display: "flex", backgroundColor: "#f7f5f5" }}>
        {/* ═════ APP BAR ═════ */}
        <MuiAppBar
          position="fixed"
          elevation={0}
          sx={{
            backgroundColor: "transparent",
            boxShadow: "none",
            ml: `${drawerWidth}px`,
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            px: 3,
          }}
        >
          <Box sx={{ width: "17%", height: "100px", display: "flex", alignItems: "center" }}>
            {companyLogo && (
              <Box
                component="img"
                src={`${process.env.REACT_APP_URL}/Images/${companyLogo}`}
                alt="Logo"
                sx={{ width: 200, height: 100, objectFit: "contain", borderRadius: 4 }}
              />
            )}
          </Box>

          <Box
            sx={{
              width: "83%",
              backgroundColor: "#3f6f7a",
              borderRadius: "16px",
              px: 3,
              py: 1.5,
              display: "flex",
              alignItems: "center",
            }}
          >
            <Toolbar disableGutters sx={{ width: "100%" }}>
              <Typography variant="h5" sx={{ color: "#fff", fontWeight: 600, ml: 2 }}>
                {companyName}
              </Typography>

              <Box sx={{ ml: "auto", display: "flex", alignItems: "center", gap: 2, pr: 2 }}>
                <IconButton sx={{ color: "#fff" }}>
                  <NotificationBell setAdminContent={setContent} />
                </IconButton>

                <Stack
                  direction="row"
                  spacing={1.5}
                  alignItems="center"
                  onClick={handleClick}
                  sx={{
                    cursor: "pointer",
                    px: 1.5,
                    py: 0.8,
                    borderRadius: 2,
                    "&:hover": { backgroundColor: "#5f9aa6" },
                  }}
                >
                  <Avatar sx={{ bgcolor: "#5f9aa6", width: 38, height: 38 }}>
                    {ProfileName?.charAt(0)}
                  </Avatar>
                  <Box sx={{ display: { xs: "none", sm: "block" } }}>
                    <Typography variant="subtitle1" color="#fff" fontWeight={600}>
                      {ProfileName}
                    </Typography>
                    <Typography variant="caption" color="#fff">
                      {role} · {today}
                    </Typography>
                  </Box>
                </Stack>

                <Menu
                  anchorEl={anchorEl}
                  open={profileopen}
                  onClose={handleClose}
                  anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                  transformOrigin={{ vertical: "top", horizontal: "right" }}
                >
                  <MenuItem
                    onClick={() => {
                      setContent("Profile");
                      handleClose();
                    }}
                  >
                    <PersonIcon fontSize="small" sx={{ mr: 1 }} />
                    Profile
                  </MenuItem>
                  <Divider />
                  <MenuItem
                    onClick={() => {
                      handleLogout();
                      handleClose();
                    }}
                    sx={{ color: "error.main" }}
                  >
                    <LogoutIcon fontSize="small" sx={{ mr: 1 }} />
                    Logout
                  </MenuItem>
                </Menu>
              </Box>
            </Toolbar>
          </Box>
        </MuiAppBar>

        {/* ═════ SIDEBAR (FULLY MODULE-DRIVEN) ═════ */}
        <Box component="nav" sx={{ width: drawerWidth, flexShrink: 0 }}>
          <MuiDrawer
            variant="permanent"
            open
            sx={{
              "& .MuiDrawer-paper": {
                width: drawerWidth,
                background: "#3f6f7a",
                color: "#fff",
                borderTopRightRadius: "40px",
                marginTop: "140px",
                height: "calc(100vh - 140px)",
              },
            }}
          >
            <List
              sx={{
                overflowY: "auto",
                overflowX: "hidden",
                scrollbarWidth: "thin",
                scrollbarColor: "#cce0e1 transparent",
                "&::-webkit-scrollbar": { width: "6px" },
                "&::-webkit-scrollbar-thumb": {
                  backgroundColor: "#cce0e1",
                  borderRadius: "10px",
                },
              }}
            >
              {/* ⭐ THIS IS THE MAGIC LINE ⭐ */}
              {/* Every user sees a different menu based on their modules[] */}
              {visibleMenu.map((item) => renderMenuItem(item))}
            </List>
          </MuiDrawer>
        </Box>

        {/* ═════ MAIN CONTENT ═════ */}
        <Box
          component="main"
          sx={{ flexGrow: 1, mt: 14, mr: 3, ml: 3, backgroundColor: "#f7f5f5" }}
        >
          <Box
            sx={{
              backgroundColor: "#fff",
              borderRadius: "20px",
              p: 2,
              minHeight: "80vh",
            }}
          >
            <Typography variant="h6" sx={{ color: "black", fontWeight: 600, mb: 2 }}>
              Dashboard / {content}
            </Typography>

            {/* Content with access check */}
            {renderContent()}
          </Box>
        </Box>
      </Box>
    </>
  );
}